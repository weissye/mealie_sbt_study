import json,sys,tempfile,unittest,subprocess,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from generator_v56.render.context_copy import generate_copy
class CopyTests(unittest.TestCase):
 def test_regeneration_and_structure(self):
  with tempfile.TemporaryDirectory() as td:
   a=Path(td)/'a/spec/js';b=Path(td)/'b/spec/js'
   for out in (a,b):generate_copy(root/'model/mealie-openapi.v3.28.0.json',out,'http://127.0.0.1:9925',33)
   for name in ('stories.mealie.js','interfaces.mealie.js','dal.js','generation_report.json'):self.assertEqual((a/name).read_bytes(),(b/name).read_bytes())
   s=(a/'stories.mealie.js').read_text();d=(a/'dal.js').read_text();g=json.loads((a/'generation_report.json').read_text());self.assertEqual(len(g['plan']['fixtures']),2);self.assertIn('ctx.bthread',s);self.assertIn('verifiedRevision>=2',d);self.assertNotIn('requestRest(',s);self.assertNotIn('linkRecipeDependencies',s)
   if shutil.which('node'):
    for f in a.glob('*.js'):subprocess.run(['node','--check',str(f)],check=True,capture_output=True)
 def test_callback_detects_historical_reference_fault(self):
  if not shutil.which('node'):self.skipTest('Node unavailable')
  from generator_v56.render.context_copy import INTERFACES
  code=INTERFACES[INTERFACES.index('function validateCopyResponse'):INTERFACES.index('function buildCopyIngredients')]
  harness=r'''
const assert=require('assert');const values={};let failures=0;
const pvg={rtv:{get:k=>values[k],set:(k,v)=>values[k]=v},fail:()=>failures++};const bp={log:{info:()=>{}}};
const plan={ingredients:'ingredients',steps:'steps',references:'refs',reference_id:'ref',text:'text',links:[]};
const original={id:'source',name:'original',ingredients:[{ref:'A',note:'a',quantity:2},{ref:'B',note:'b',quantity:4}],steps:[{text:'mix',refs:[{ref:'A'},{ref:'B'}]}]};
const expected={sourceId:'source',source:original,copyName:'copy'};
function receipt(kind,obj,finish=false){validateCopyResponse({body:JSON.stringify(obj),code:200},plan,kind,expected,finish);}
function run(fault){receipt('source-before',original);const copy=JSON.parse(JSON.stringify(original));copy.id='copy-id';copy.slug='copy';copy.name='copy';copy.ingredients[0].ref='C';copy.ingredients[1].ref='D';if(!fault)copy.steps[0].refs=[{ref:'D'},{ref:'C'}];receipt('copy-response',copy);receipt('copy-get',copy);receipt('source-after',original);receipt('copy-get',copy,true);return JSON.parse(values.F03_REVIEW);}
assert.equal(run(false).issues.length,0);assert.equal(failures,0);const bad=run(true);assert(bad.issues.some(x=>x.includes('outside this recipe')));assert.equal(bad.receipts.length,5);assert.equal(failures,1);
'''
  subprocess.run(['node','-e',code+harness],check=True,capture_output=True)
if __name__=='__main__':unittest.main()
