import argparse,hashlib,json,zipfile
from pathlib import Path
from native_log_text import decode_native_log
p=argparse.ArgumentParser();p.add_argument('--project',required=True);root=Path(p.parse_args().project)
raw=(root/'native-run.log').read_bytes();text=decode_native_log(raw);receipts=[];reviews=[]
for line in text.splitlines():
 for marker,rows in [('F03_RECEIPT ',receipts),('F03_EVIDENCE ',reviews)]:
  if marker in line:rows.append(json.loads(line.split(marker,1)[1]))
last=reviews[-1] if reviews else None
complete=bool(last and len(receipts)==5 and [r['kind'] for r in receipts]==['source-before','copy-response','copy-get','source-after','copy-get'])
status=last['status'] if complete else 'F03_INCOMPLETE'
accepted=complete and not last['issues'] and 'Test Result: SUCCESS' in text
q={'status':status,'observations_completed':complete,'functional_pass':accepted,'native_provengo_executed':True,'new_bug_confirmed':False,'receipts':receipts,'review':last,'native_log_sha256':hashlib.sha256(raw).hexdigest(),'raw_log_included':False,'limitation':'Requires independent qualification; OpenAPI does not fully specify copy reference remapping.'}
(root/'qualification.json').write_text(json.dumps(q,indent=2))
with zipfile.ZipFile(root/'review.zip','w',zipfile.ZIP_DEFLATED) as z:
 for directory in ('spec/js','config'):
  for f in (root/directory).rglob('*'):
   if f.is_file() and f.suffix in ('.js','.json','.yml'):z.write(f,f.relative_to(root))
 z.write(root/'qualification.json','qualification.json')
print(status);print('Review ZIP: '+str(root/'review.zip'))
