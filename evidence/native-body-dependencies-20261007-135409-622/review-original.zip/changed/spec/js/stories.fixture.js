// Generated stories: explicit entity instances; Context-driven verification.
// HTTP paths and request bodies are confined to interfaces.
ctx.bthread("protectWriteAndReadback", "WriteLock.All", function(lock) {
    sync({block:matchesConflictingWrites(lock.logicalId,lock.owner),waitFor:matchesVerified(lock.logicalId,lock.revision)});
});
ctx.bthread("protectPendingVerification", "Verification.Pending", function(resource) {
    sync({block:matchesMutations(resource.id),waitFor:matchesVerified(resource.id,resource.revision)});
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyFixtureResourceAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="FixtureResource") return;
    verifyFixtureResource(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance FixtureResource_1: creation, independent readback, update, independent readback.
bthread("lifecycle FixtureResource_1", function() {
    var parents=waitForDependencies([]);
    createFixtureResource("FixtureResource_1",{"name":"sbt-20261007-FixtureResource-1-name"},parents);
    waitFor(matchesVerified("FixtureResource_1",1));
    updateFixtureResource(getModelEntity("FixtureResource_1"),{"name":"sbt-20261007-FixtureResource_1-updated"});
    waitFor(matchesVerified("FixtureResource_1",2));
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyFoodAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="Food") return;
    verifyFood(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance Food_1: creation, independent readback, update, independent readback.
bthread("lifecycle Food_1", function() {
    var parents=waitForDependencies([]);
    createFood("Food_1",{"name":"sbt-20261007-Food-1-name"},parents);
    waitFor(matchesVerified("Food_1",1));
    updateFood(getModelEntity("Food_1"),{"name":"sbt-20261007-Food_1-updated"});
    waitFor(matchesVerified("Food_1",2));
});

// Verification is activated by a Context query, independently of producers.
ctx.bthread("verifyUnitAfterEveryWrite", "Verification.Pending", function(resource) {
    if(resource.resourceType!=="Unit") return;
    verifyUnit(resource);
    request(bp.Event("ModelVerified",{logicalId:resource.id,revision:resource.revision}));
});

// Instance Unit_1: creation, independent readback, update, independent readback.
bthread("lifecycle Unit_1", function() {
    var parents=waitForDependencies([]);
    createUnit("Unit_1",{"name":"sbt-20261007-Unit-1-name"},parents);
    waitFor(matchesVerified("Unit_1",1));
    updateUnit(getModelEntity("Unit_1"),{"name":"sbt-20261007-Unit_1-updated"});
    waitFor(matchesVerified("Unit_1",2));
});


// Separate Context verifier bthread per pending observation instance.
ctx.bthread('complete observed response','Observation.Pending',function(observation){
    for(var index=0;index<observation.targets.length;index++) {
        readObservedTarget(observation,observation.targets[index],index);
    }
    sync({request:bp.Event('ObservationCompleted',{id:observation.id})});
});
ctx.bthread('protect observation readbacks','Observation.All',function(observation){
    var protectedWrites=bp.EventSet('Observed resources',function(event){
        if(event.name==='ObservationBegin') return !!(event.data && event.data.targets && event.data.targets.some(function(t){return observation.targets.some(function(p){return p.logicalId===t.logicalId;});}));
        var model=event.data && event.data.model;
        return !!(model && (model.action==='update' || model.action==='create') &&
            observation.targets.some(function(t){return (model.affected || [model.logicalId]).indexOf(t.logicalId)>=0;}));
    });
    var completed=bp.EventSet('Observation done',function(event){return !!(event.name==='ObservationCompleted' && event.data && event.data.id===observation.id);});
    sync({block:protectedWrites,waitFor:completed});
});

function waitForActionDependencies(bindings) {
    while(true) {
        var chosen={},complete=true;
        var all=ctx.runQuery("Resource.All");
        var names=Object.keys(bindings);
        for(var i=0;i<names.length;i++) {
            var name=names[i],binding=bindings[name],found=null;
            for(var k=0;k<all.length;k++) if(all[k].id===binding.id) found=all[k];
            if(!found || found.verifiedRevision<binding.revision || found.verifiedRevision!==found.revision) complete=false;
            else chosen[name]=found;
        }
        if(complete) return chosen;
        waitFor(bp.EventSet("Any action dependency verified",function(event){return !!(event.name==="ModelVerified");}));
    }
}
// #/paths/~1resources~1{id}~1action/post
bthread("process_0_FixtureResource_1",function(){
    var resources=waitForActionDependencies({"FixtureResource":{"id":"FixtureResource_1","revision":2},"Food":{"id":"Food_1","revision":2},"Unit":{"id":"Unit_1","revision":2}});
    observeProcess0(resources,{"FixtureResource":"ID_FixtureResource_1","Food":"ID_Food_1","Unit":"ID_Unit_1"},{"FixtureResource":"ROUTE_FixtureResource_1","Food":"ROUTE_Food_1","Unit":"ROUTE_Unit_1"},"process_0_FixtureResource_1");
    sync({waitFor:bp.Event("ObservationCompleted",{id:"process_0_FixtureResource_1"})});
});
