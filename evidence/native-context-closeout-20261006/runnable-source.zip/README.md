# Context generator: native live integration

This build extends the same uploaded generator_v56 (0.26.19-parallel-crud.3).
It generates built-in Context models plus authentication and a complete minimal
Provengo project. It is not the F01 contribution/quantity reproduction.

## What changed

1. `dal.js` explicitly summons the built-in Context library. The user's
   0.7.5-SNAPSHOT native log confirmed automatic Context loading.
2. Generation into `spec/js` also creates `config/provengo.yml` with version 2
   and a 200-event bound, without the default example's `addMetadata` hook.
3. Authentication is inferred from OpenAPI's referenced OAuth2 password flow,
   local token POST and form schema. Ambiguous/unsupported schemes fail.
4. A separate authentication bthread calls the named interface function.
   Another bthread blocks business HTTP until `AuthenticationReady`.
5. The authentication callback checks the OAuth2 access token and bearer token
   type, then stores the real token using `pvg.rtv.set`. The token response schema
   in this contract is empty: the access_token/token_type checks implement the
   declared OAuth2 protocol, not undocumented application quantity semantics.
6. Credentials are evaluated at execution from SBT_USERNAME/SBT_PASSWORD process
   environment variables. Generated JS and symbolic samples contain expressions,
   not credentials. The launcher prompts for a hidden password and restores the
   prior environment in finally. Provengo execution reports can contain evaluated
   HTTP data: retain them locally and redact authentication data before sharing.

## Native evidence already supplied by the user

The PREVIOUS generated build produced one native 0.7.5-SNAPSHOT sample with 45
events: 28 planned business HTTP actions, five entity creations, six updates and
17 GETs. All five lifecycles reached their final ModelVerified marker. The item
POST followed verification of all four parents. This confirms symbolic sampling
of that earlier build only; it is not a live SUT result or evidence for this
new authentication path.

## Run on Windows

Extract this archive into a new directory. Do not overlay the established study
or original generator_v56. In `mealie-context-live` run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
Unblock-File '.\scripts\Run-Mealie-Context-Live.ps1'
& .\scripts\Run-Mealie-Context-Live.ps1 -Username 'changeme@example.com'
```

The script runs local tests, generates a fresh one-instance Context project with
new names/seed, prompts for a password and invokes `provengo run`. All HTTP,
including authentication, is requested by generated interfaces through native
REST events. It prints paths to stories/interfaces/DAL and saves native-run.log.
No external HTTP runner, simultaneous-request coordinator, cleanup, deletion,
automatic retry, reset or Git action is performed. Fixture resources are retained.
An exit zero is reported as an engine result, not an automatically confirmed bug
or complete acceptance. Review the actual native trace and readbacks.

Requirements: Python 3, Node.js, Java and installed Provengo. Base URL defaults to
http://127.0.0.1:9925. The exact uploaded v3.28.0 contract is byte-pinned (SHA256
90e19aa713ab4ba15352627aca7dc37290f868b213eb65a3e1564f3b7a7ff292).

Generation without execution remains available with Generate-Mealie-Context.ps1.
The checked-in `generated` project is for review; the live launcher regenerates
fresh fixtures. Use the launcher for real execution rather than dry run, since
real IDs and tokens are captured from live responses.

## Model and oracle boundaries

Each entity instance has a create/read/update/readback lifecycle bthread.
Dependency readiness selects available parents without a fixed creation order.
A separate linking process attaches two ingredients sharing food/unit to the
recipe. Context activates separate verifiers and affected-resource write guards.
Expected projections come from requests; real server IDs are stored at the
interface boundary in RTVs. PUT carry uses pre-write reads under modeled guards.

No DELETE lifecycle, recipe contribution, merge algebra, copy semantics,
multi-account probing or F01 quantity oracle is claimed. Schema/title/key mapping
uses reported generic heuristics. Arrays are currently compared positionally;
reordering requires qualification. Live runtime compatibility, server responses,
callbacks and independent reads remain to be validated on the user's machine.

## Validation status

Seven Python regressions and 43 Node callback/DAL checks pass locally. Auth tests
check endpoint derivation, missing/wrong token rejection, token storage, business
HTTP discrimination and absence of credentials in generated source. The existing
24 parent readiness permutations remain covered by the unit harness. This is
not a native scheduler simulation.

No Provengo binary/JAR or Mealie server was available in the build environment.
No native execution, SUT request or PowerShell runtime test was performed here.
The environment expressions and new authentication gate require native acceptance.
