# Actor native runner repair

The user review showed generation failed before native execution because the selected central-process-binding payload lacked package entry points and common modules. Provengo was present at version 0.7.5-SNAPSHOT.

This repair restores only absent Python source files from the original review(20261007-103347) source snapshot. Existing files are never replaced. The actor delta already installed by the previous run remains in place. Do not use -InstallDelta for this repair.

Run Run-Context-Actors.ps1 with the existing generator root. The runner uses the central CLI main function, then native Provengo against a single-threaded shared fixture. Accepted evidence is written to review.zip and independently verified. No Mealie requests or Git operations occur.

The uploaded user-source snapshot was exercised locally after restoration: native exit 0, 18 successful HTTP requests, four actor/resource combinations, four qualified observations. The accepted archive is included as accepted-user-source-review.zip. The PowerShell wrapper has not been executed in this Linux authoring environment.
