"""Verify native actor-fixture evidence; blocked attempts are never accepted."""
import json,sys,zipfile
from collections import Counter
from pathlib import Path

def main():
    with zipfile.ZipFile(Path(sys.argv[1])) as archive:
        assert archive.testzip() is None, 'Damaged archive'
        result=json.loads(archive.read('result.json'))
        assert result['status']=='CONTEXT_ACTORS_NATIVE_FIXTURE_PASS', 'Native acceptance absent: '+result['status']
        assert result['native_provengo_executed'] and result['native_exit']==0
        assert result['fixture_only'] and result['sut_requests']==0
        receipts=result['fixture_requests']
        assert len(receipts)==18 and all(r['status'] in (200,201) for r in receipts)
        creators=result['resource_creators']
        assert Counter(creators.values())==Counter({'A':1,'B':1})
        actions=Counter((r['actor'],r['path']) for r in receipts if r['method']=='POST' and r['path'].endswith('/action'))
        assert actions==Counter((a,'/resources/'+i+'/action') for a in ['A','B'] for i in creators)
        observations=result['observations']
        assert len(observations)==4 and Counter(o.get('actor') for o in observations)==Counter({'A':2,'B':2})
        assert all(o.get('observationsComplete') and o.get('contractStatusValid') and len(o.get('readbacks',[]))==1 and o['readbacks'][0].get('identityMatches') and o['readbacks'][0].get('expectedMatches') for o in observations)
        assert not result['reasons']
        assert 'project/native-run.log' in archive.namelist()
        assert 'generator-source.zip' in archive.namelist()
    print('CONTEXT_ACTORS_ARCHIVE_VERIFIED')

if __name__=='__main__':
    try:main()
    except (AssertionError,KeyError,ValueError,OSError,zipfile.BadZipFile) as error:
        print('CONTEXT_ACTORS_ARCHIVE_NOT_ACCEPTED:',error);sys.exit(1)
