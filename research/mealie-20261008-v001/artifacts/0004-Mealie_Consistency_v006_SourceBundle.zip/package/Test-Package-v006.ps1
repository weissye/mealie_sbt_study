# Verifies every file listed in manifest_v006.json (version and SHA256). Local only.
$ErrorActionPreference = 'Stop'
$Version = 'v006'
$manifest = Get-Content (Join-Path $PSScriptRoot 'manifest_v006.json') -Raw | ConvertFrom-Json
if ($manifest.version -ne $Version) { throw "Package version mismatch: $($manifest.version)" }
foreach ($entry in $manifest.files) {
    $path = Join-Path $PSScriptRoot $entry.path
    if (-not (Test-Path -LiteralPath $path)) { throw "Missing package file: $($entry.path)" }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256.ToUpper()) {
        throw "Package checksum mismatch: $($entry.path)"
    }
}
Write-Host "PACKAGE $Version verified: $($manifest.files.Count) files"
