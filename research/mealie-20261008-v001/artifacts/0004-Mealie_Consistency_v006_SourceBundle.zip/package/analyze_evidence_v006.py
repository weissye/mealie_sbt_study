"""Offline F04/F05 evidence analyzer, study configuration v006.

Reads the preserved research collection ZIP (nested ZIPs are read in memory, nothing is
extracted or executed) and writes:
  evidence_table_v006.json  - one row per HTTP 500 observation plus run summaries
  evidence_table_v006.md    - the same table for reading
  inventory_v006.json       - requested items found / missing, duplicates, SHA256

No network access. No Mealie API calls. Python 3 standard library only.

Usage: python analyze_evidence_v006.py <collection.zip> [--out DIR] [--mealie-src DIR]
"""

import argparse
import hashlib
import io
import json
import pathlib
import re
import sys
import zipfile

VERSION = "v006"
SCRIPT = "analyze_evidence_v006.py"
SENTINEL_RECIPE = "00000000-0000-4000-8000-000000000001"

# Step semantics are declared explicitly, taken from the campaign protocols
# (Mealie_Foreign_Recipe_Reference_Server_Error.md, Mealie_Reference_And_Household_Controls.md).
# target_list: whose list the request writes to; recipe: whose recipe is referenced.
STEP_SPEC = {
    "multi-identity/separate": {
        "foreign_add_a": {"actor": "A", "target_list": "A", "recipe": "B", "relation": "other group recipe -> own list"},
        "foreign_add_b": {"actor": "B", "target_list": "B", "recipe": "A", "relation": "other group recipe -> own list"},
    },
    "scope-controls/reference-controls": {
        "cross_add_a": {"actor": "A", "target_list": "A", "recipe": "B", "relation": "other group recipe -> own list"},
        "cross_add_b": {"actor": "B", "target_list": "B", "recipe": "A", "relation": "other group recipe -> own list"},
        "missing_add_a": {"actor": "A", "target_list": "A", "recipe": "SENTINEL", "relation": "absent recipe -> own list"},
        "missing_add_b": {"actor": "B", "target_list": "B", "recipe": "SENTINEL", "relation": "absent recipe -> own list"},
    },
    "scope-controls/household-controls": {
        "other_list_add_a": {"actor": "A", "target_list": "B", "recipe": "A", "relation": "own recipe -> other household list (same group)"},
        "other_list_add_b": {"actor": "B", "target_list": "A", "recipe": "B", "relation": "own recipe -> other household list (same group)"},
    },
}

REQUESTED = [
    ("Mealie_Shared_Consistency_v005.zip", r"Mealie_Shared_Consistency_v005\.zip$"),
    ("review(20261008-121634).zip (v005 live success evidence)", r"review.*20261008-121634.*\.zip$|v005.*/review\.zip$"),
    ("Mealie_Quantity_Consistency_Engineering_and_Research.docx", r"Mealie_Quantity_Consistency_Engineering_and_Research\.docx$"),
    ("multi-identity-20261005-065704", r"multi-identity-20261005-065704/"),
    ("scope-controls-20261005-073218", r"scope-controls-20261005-073218/"),
    ("qualification.json", r"(^|/)qualification\.json$"),
    ("campaign run results (result-N.json / live-N.zip)", r"(^|/)(result-\d\.json|live-\d\.zip)$"),
    ("campaign configuration (campaign-config.json)", r"(^|/)campaign-config\.json$"),
    ("server logs (server-logs.txt)", r"(^|/)server-logs\.txt$"),
    ("mealie-openapi.v3.28.0.reviewed.json", r"mealie-openapi\.v3\.28\.0\.reviewed\.json$"),
    ("Mealie source for each recorded commit", r"(^|/)mealie/services/household_services/shopping_lists\.py$"),
]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def norm(name: str) -> str:
    return name.replace("\\", "/")


def walk(zbytes: bytes, prefix: str, out: list, depth: int = 0):
    """Yield (path, bytes) for every member, descending into nested ZIPs up to depth 4."""
    with zipfile.ZipFile(io.BytesIO(zbytes)) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = prefix + norm(info.filename)
            data = z.read(info)
            out.append((name, data))
            if name.lower().endswith(".zip") and depth < 4:
                try:
                    walk(data, name + "!/", out, depth + 1)
                except zipfile.BadZipFile:
                    pass


def item_key(item: dict) -> dict:
    return {
        "id": item.get("id"),
        "quantity": item.get("quantity"),
        "note": item.get("note"),
        "createdAt": item.get("createdAt"),
        "recipeIds": sorted(r.get("recipeId") for r in item.get("recipeReferences", [])),
    }


def run_rows(campaign: str, case: str, sample: int, receipt: dict, live_sha: str, logs: list, meta: dict):
    ip = receipt["runtime_receipt"]["identity_program"]
    obs, order = ip["observations"], ip["order"]
    users, recipes, lists = {}, {}, {}
    for key in order:
        v = obs.get(key, {})
        b = v.get("body")
        if key in ("self_a", "self_b") and isinstance(b, dict):
            users[key[-1].upper()] = b
        if isinstance(b, dict) and "recipeIngredient" in b and key.startswith(("read_", "seed_")):
            recipes.setdefault(v["actor"], b.get("id"))
        if key in ("list_a", "list_b") and isinstance(b, dict):
            lists[key[-1].upper()] = b.get("id")
    spec = STEP_SPEC.get(campaign + "/" + case, {})
    rows = []
    for idx, key in enumerate(order):
        v = obs.get(key, {})
        if v.get("code") != 500:
            continue
        s = spec.get(key)
        row = {
            "campaign": campaign, "case": case, "sample": sample, "step": key,
            "actor": v.get("actor"), "operation": v.get("operation"),
            "request_body": v.get("request_body"), "status": 500,
            "live_zip_sha256": live_sha, "namespace": ip.get("namespace"),
            **meta,
        }
        if not s:
            row["classification"] = "UNSPECIFIED_STEP"
            rows.append(row)
            continue
        list_id = lists.get(s["target_list"])
        recipe_id = SENTINEL_RECIPE if s["recipe"] == "SENTINEL" else recipes.get(s["recipe"])
        actor_u, list_owner = users.get(s["actor"], {}), users.get(s["target_list"], {})
        row.update(
            relation=s["relation"], target_list_id=list_id, target_list_owner=s["target_list"],
            recipe_id=recipe_id,
            actor_group=actor_u.get("groupId"), actor_household=actor_u.get("householdId"),
            list_owner_group=list_owner.get("groupId"), list_owner_household=list_owner.get("householdId"),
            actor_roles={k: actor_u.get(k) for k in ("admin", "canManage", "canManageHousehold", "canOrganize")},
        )
        before = after = None
        before_step = after_step = None
        for k in reversed(order[:idx]):
            b = obs.get(k, {}).get("body")
            if isinstance(b, dict) and b.get("id") == list_id and "listItems" in b:
                before, before_step = b, k
                break
        intervening = []
        for k in order[idx + 1:]:
            ob = obs.get(k, {})
            b = ob.get("body")
            if isinstance(b, dict) and b.get("id") == list_id and "listItems" in b:
                after, after_step = b, k
                break
            intervening.append(k)
        row["before_step"], row["after_step"] = before_step, after_step
        row["after_reader"] = obs.get(after_step, {}).get("actor") if after_step else None
        row["intervening_steps"] = intervening
        if before is not None and after is not None:
            bi = {i["id"]: item_key(i) for i in before["listItems"]}
            ai = {i["id"]: item_key(i) for i in after["listItems"]}
            added = [ai[i] for i in ai if i not in bi]
            removed = [bi[i] for i in bi if i not in ai]
            changed = [i for i in ai if i in bi and ai[i] != bi[i]]
            row.update(
                before_items=len(bi), after_items=len(ai),
                before_list_refs=sorted(r.get("recipeId") for r in before.get("recipeReferences", [])),
                after_list_refs=sorted(r.get("recipeId") for r in after.get("recipeReferences", [])),
                added_items=added, removed_item_ids=[r["id"] for r in removed], changed_item_ids=changed,
                state_changed=bool(added or removed or changed),
            )
        # server log correlation (only where a log capture exists)
        row["server_exception"] = None
        if logs:
            needle = f'500 Internal Server Error "POST /api/households/shopping/lists/{list_id}/recipe/{recipe_id} '
            row["server_exception"] = "LOG_NOT_CAPTURED_FOR_THIS_REQUEST"
            for li, line in enumerate(logs):
                if needle in line:
                    m = re.search(r"^(\S+)", line)
                    row["server_log_time"] = m.group(1) if m else None
                    for nxt in logs[li + 1: li + 160]:
                        e = re.search(r"Z\s+((?:mealie\.core\.exceptions\.)?\w+(?:Error|None)): (.*)$", nxt)
                        if e:
                            row["server_exception"] = e.group(1) + ": " + e.group(2)
                            frames = []
                            for f in logs[li + 1: logs.index(nxt) + 1]:
                                fm = re.search(r'site-packages/(mealie/\S+\.py)", line (\d+), in (\w+)', f)
                                if fm:
                                    frames.append(f"{fm.group(1)}:{fm.group(2)} {fm.group(3)}")
                            row["mealie_frames"] = frames
                            break
                    break
            for item in row.get("added_items", []):
                item["created_before_500_logged"] = bool(row.get("server_log_time")) and item["createdAt"] <= row["server_log_time"]
        rows.append(row)
    return rows


def classify(row: dict) -> str:
    exc = row.get("server_exception") or ""
    if row.get("state_changed"):
        if "AttributeError" in exc:
            return "F05"
        return "F05_CANDIDATE_NO_TRACEBACK"
    if "UnexpectedNone" in exc or row.get("relation", "").endswith("-> own list"):
        return "F04"
    return "UNCLASSIFIED"


def main():
    print(f"MEALIE_EVIDENCE_ANALYZER {VERSION}", flush=True)
    p = argparse.ArgumentParser()
    p.add_argument("collection")
    p.add_argument("--out", default=".")
    p.add_argument("--mealie-src", default=None, help="optional Mealie checkout to record the source revision")
    a = p.parse_args()
    raw = pathlib.Path(a.collection).read_bytes()
    entries: list = []
    walk(raw, "", entries)
    out = pathlib.Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    # ---------------- inventory
    by_hash: dict = {}
    for name, data in entries:
        by_hash.setdefault(sha256(data), []).append(name)
    inventory = {"version": VERSION, "script": SCRIPT, "collection_sha256": sha256(raw),
                 "member_count_recursive": len(entries), "requested": [], "duplicate_groups": []}
    for label, pattern in REQUESTED:
        hits = [n for n, _ in entries if re.search(pattern, n, re.I)]
        inventory["requested"].append({"item": label, "found": bool(hits), "count": len(hits), "examples": hits[:4]})
    for h, names in by_hash.items():
        if len(names) > 1 and not all(n.endswith(".py") for n in names):
            inventory["duplicate_groups"].append({"sha256": h, "copies": len(names), "paths": names[:8]})
    inventory["duplicate_groups"].sort(key=lambda g: -g["copies"])

    # ---------------- campaigns (first copy of each distinct campaign archive)
    blobs = dict(entries)
    camps = {}
    for name, data in entries:
        if not name.endswith("campaign-original.zip"):
            continue
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            members = {norm(n) for n in z.namelist()}
        kind = "scope-controls" if "household-controls/live-1.zip" in members else (
            "multi-identity" if "separate/live-1.zip" in members else None)
        if kind:
            camps.setdefault(kind, {}).setdefault(sha256(data), []).append(name)
    rows, runs = [], []
    for kind, variants in sorted(camps.items()):
        if len(variants) != 1:
            print(f"WARNING: {kind} has {len(variants)} distinct archive versions", file=sys.stderr)
        chash, paths = next(iter(variants.items()))
        # prefer the copy that carries the most sidecar files (qualification, environment, provenance)
        def sidecars(pth):
            b = pth.rsplit("/", 1)[0]
            return sum(b + "/" + f in blobs for f in ("qualification.json", "environment.json", "source-provenance.json"))
        src = sorted(paths, key=lambda pth: (-sidecars(pth), pth))[0]
        base = src.rsplit("/", 1)[0] if "/" in src else ""
        qual = None
        for cand in (base + "/qualification.json",):
            if cand in blobs:
                qual = json.loads(blobs[cand].decode("utf-8-sig"))
        env = json.loads(blobs[base + "/environment.json"].decode("utf-8-sig")) if base + "/environment.json" in blobs else {}
        prov = json.loads(blobs[base + "/source-provenance.json"].decode("utf-8-sig")) if base + "/source-provenance.json" in blobs else {}
        prefix = src + "!/"
        logs = blobs.get(prefix + "server-logs.txt", b"").decode("utf-8", "replace").splitlines()
        server_check = json.loads(blobs[prefix + "server-check.json"]) if prefix + "server-check.json" in blobs else {}
        qual_variants = {}
        for pth in paths:
            q = pth.rsplit("/", 1)[0] + "/qualification.json"
            if q in blobs:
                qv = json.loads(blobs[q].decode("utf-8-sig"))
                qual_variants.setdefault(sha256(blobs[q]), qv.get("source_commit"))
        if qual is None and qual_variants:
            qual = next(json.loads(blobs[pth.rsplit("/", 1)[0] + "/qualification.json"].decode("utf-8-sig"))
                        for pth in paths if pth.rsplit("/", 1)[0] + "/qualification.json" in blobs)
        meta = {
            "server_version_observed": (server_check.get("observed") or {}).get("version"),
            "study_commit_recorded": sorted({c for c in qual_variants.values() if c}),
            "qualification_variants": len(qual_variants),
            "study_commit_original_execution": env.get("original_source_commit"),
            "study_commit_provenance_note": prov.get("snapshot_basis"),
            "campaign_archive_sha256": chash,
            "campaign_archive_copies": len(paths),
            "server_log_captured": bool(logs),
        }
        cases = ("reference-controls", "household-controls") if kind == "scope-controls" else ("shared", "separate")
        for case in cases:
            for sample in (1, 2):
                lz = blobs.get(f"{prefix}{case}/live-{sample}.zip")
                if lz is None:
                    continue
                with zipfile.ZipFile(io.BytesIO(lz)) as z:
                    receipt = json.loads(z.read("run-acceptance.json"))
                rr = receipt["runtime_receipt"]
                qrun = next((r for r in (qual or {}).get("runs", []) if r.get("case") == case and r.get("sample") == sample), {})
                expected_sha = qrun.get("live_sha256") or qrun.get("sha256")
                new_rows = run_rows(kind, case, sample, receipt, sha256(lz), logs, meta)
                runs.append({
                    "campaign": kind, "case": case, "sample": sample, "status": receipt.get("status"),
                    "responses": rr.get("response_count"), "http_500": len(new_rows),
                    "live_zip_sha256": sha256(lz), "matches_qualification_sha256": expected_sha == sha256(lz),
                    "qualification_label_unauthorized_changes": len(qrun.get("unauthorized_changes", [])) if qrun else None,
                })
                rows.extend(new_rows)
    for r in rows:
        r["finding"] = classify(r)

    # ---------------- Mealie source check (optional)
    source = {"tag_expected": "v3.28.0", "checked": False}
    if a.mealie_src:
        f = pathlib.Path(a.mealie_src) / "mealie/services/household_services/shopping_lists.py"
        if f.exists():
            lines = f.read_text(encoding="utf-8").splitlines()
            source.update(checked=True, file_sha256=sha256(f.read_bytes()),
                          line_134=lines[133].strip(), line_219=lines[218].strip(),
                          line_342=lines[341].strip(), line_449=lines[448].strip())

    summary = {
        "version": VERSION, "script": SCRIPT, "collection_sha256": sha256(raw),
        "runs": runs, "observations_http_500": len(rows),
        "by_finding": {k: sum(1 for r in rows if r["finding"] == k) for k in sorted({r["finding"] for r in rows})},
        "state_changed_observations": sum(1 for r in rows if r.get("state_changed")),
        "server_log_matched": sum(1 for r in rows if (r.get("server_exception") or "").startswith(("Attr", "mealie"))),
        "mealie_source": source,
        "rows": rows,
    }
    (out / "evidence_table_v006.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (out / "inventory_v006.json").write_text(json.dumps(inventory, indent=2), encoding="utf-8")

    md = [f"# Evidence table {VERSION}", "", f"Generated by `{SCRIPT}` from collection SHA256 `{sha256(raw)}`.", "",
          "| # | Finding | Campaign/case | S | Step | Relation | Before→after items | New item createdAt | Server exception (log) | Study commit |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for i, r in enumerate(rows, 1):
        added = r.get("added_items") or []
        md.append("| {} | {} | {}/{} | {} | {} | {} | {}→{} | {} | {} | {} |".format(
            i, r["finding"], r["campaign"], r["case"], r["sample"], r["step"], r.get("relation", ""),
            r.get("before_items", "?"), r.get("after_items", "?"),
            ", ".join(x["createdAt"] for x in added) or "—",
            r.get("server_exception") or "no log captured",
            ", ".join(c[:10] for c in r.get("study_commit_recorded") or []) or "not recorded"))
    md += ["", "## Runs", "", "| Campaign | Case | Sample | Status | Responses | HTTP 500 | live ZIP SHA matches qualification |", "|---|---|---|---|---|---|---|"]
    for r in runs:
        md.append(f"| {r['campaign']} | {r['case']} | {r['sample']} | {r['status']} | {r['responses']} | {r['http_500']} | {r['matches_qualification_sha256']} |")
    md += ["", "## Inventory", "", "| Requested item | Found | Copies |", "|---|---|---|"]
    for it in inventory["requested"]:
        md.append(f"| {it['item']} | {'yes' if it['found'] else '**MISSING**'} | {it['count']} |")
    (out / "evidence_table_v006.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps({k: summary[k] for k in ("observations_http_500", "by_finding", "state_changed_observations", "server_log_matched")}))
    print("Wrote", out / "evidence_table_v006.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
