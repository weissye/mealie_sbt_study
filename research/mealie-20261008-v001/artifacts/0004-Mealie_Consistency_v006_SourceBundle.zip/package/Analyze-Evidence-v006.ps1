# Offline F04/F05 evidence table, configuration v006 (LOCAL: reads the collection ZIP, no HTTP).
param([Parameter(Mandatory = $true)][string]$Collection)
$ErrorActionPreference = 'Stop'
$Version = 'v006'
Write-Host "MEALIE_EVIDENCE_ANALYZER $Version launcher Analyze-Evidence-v006.ps1"
& (Join-Path $PSScriptRoot 'Test-Package-v006.ps1')
$out = Join-Path $PSScriptRoot ("evidence-$Version-" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$py = if (Get-Command py -ErrorAction SilentlyContinue) { @('py', '-3', '-I') } else { @('python', '-I') }
& $py[0] $py[1..($py.Count - 1)] (Join-Path $PSScriptRoot 'analyze_evidence_v006.py') $Collection --out $out
if ($LASTEXITCODE -ne 0) { throw "Analyzer $Version failed." }
Write-Host "Evidence table: $out"
