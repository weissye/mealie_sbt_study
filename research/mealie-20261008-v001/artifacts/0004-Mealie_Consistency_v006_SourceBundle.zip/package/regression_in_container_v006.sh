#!/bin/sh
# Mealie regression for configuration v006. Runs inside python:3.14-slim (digest pinned by the
# launcher, same base image as Mealie v3.28.0's Dockerfile). Mounted: /pkg (read-only), /out.
set -eu
VERSION=v006
TAG=v3.28.0
TAG_COMMIT=0552eaa4a80031b8572849cca0ed95d07f1be001
T=tests/integration_tests/user_household_tests
echo "MEALIE_REGRESSION $VERSION regression_in_container_v006.sh tag=$TAG"
apt-get update -qq
apt-get install -y -qq --no-install-recommends git build-essential libpq-dev libsasl2-dev libldap2-dev libssl-dev >/dev/null
pip install -q uv
echo "uv: $(uv --version)" | tee /out/tool_versions_$VERSION.txt
python3 --version | tee -a /out/tool_versions_$VERSION.txt
git clone -q --depth 1 --branch "$TAG" https://github.com/mealie-recipes/mealie.git /src
cd /src
HEAD=$(git rev-parse HEAD)
echo "source HEAD: $HEAD" | tee -a /out/tool_versions_$VERSION.txt
[ "$HEAD" = "$TAG_COMMIT" ] || { echo "tag commit mismatch"; exit 2; }
git apply /pkg/mealie-v3.28.0-regression-tests-v006.patch
uv sync --frozen --group dev
echo "== baseline: v3.28.0 + v006 tests, no fix"
uv run pytest -q -p no:cacheprovider "$T/test_shopping_list_rejected_writes_v006.py" \
  --junitxml=/out/baseline_$VERSION.xml || true
git apply /pkg/mealie-v3.28.0-rejected-write-guard-v006.patch
git diff --stat | tee /out/applied_diffstat_$VERSION.txt
echo "== patched: v006 tests + existing shopping-list and repository-scope suites"
uv run pytest -q -p no:cacheprovider "$T/test_shopping_list_rejected_writes_v006.py" \
  "$T/test_group_shopping_lists.py" "$T/test_group_shopping_list_items.py" \
  tests/integration_tests/test_repository_factory.py \
  --junitxml=/out/patched_$VERSION.xml || true
python3 /pkg/summarize_junit_v006.py /out/baseline_$VERSION.xml /out/patched_$VERSION.xml /out/regression_$VERSION.json
