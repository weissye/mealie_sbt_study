"""Summarize the v006 Mealie regression JUnit files and apply the acceptance rule.

Baseline (fix absent):   every test_v006_* rejection test fails; every test_v006_control_* passes.
                         test_v006_h3_* probes a source-level hypothesis: its baseline outcome is
                         reported (failed = hypothesis confirmed) but is not part of acceptance.
Patched  (fix applied):  every collected test passes (v006 tests and existing suites).
"""
import json
import sys
import xml.etree.ElementTree as ET

VERSION = "v006"
SCRIPT = "summarize_junit_v006.py"


def outcomes(path):
    res = {}
    for case in ET.parse(path).getroot().iter("testcase"):
        name = case.get("classname", "") + "::" + case.get("name", "")
        if case.find("failure") is not None or case.find("error") is not None:
            res[name] = "failed"
        elif case.find("skipped") is not None:
            res[name] = "skipped"
        else:
            res[name] = "passed"
    return res


def main():
    base, patched, out = sys.argv[1:4]
    b, p = outcomes(base), outcomes(patched)
    v006 = lambda d: {k: v for k, v in d.items() if "rejected_writes_v006" in k}
    ctrl = lambda k: "test_v006_control_" in k
    hyp = lambda k: "test_v006_h3_" in k
    baseline_ok = bool(v006(b)) and all(
        (v == "passed") if ctrl(k) else (v == "failed") for k, v in v006(b).items() if not hyp(k)
    )
    hypotheses = {k: ("CONFIRMED_BY_BASELINE_FAILURE" if v == "failed" else "NOT_CONFIRMED") for k, v in v006(b).items() if hyp(k)}
    patched_ok = bool(p) and all(v == "passed" for v in p.values()) and len(v006(p)) == len(v006(b))
    report = {
        "version": VERSION, "script": SCRIPT, "kind": "MEALIE_TEST_SUITE_SQLITE_NOT_LIVE_SERVER",
        "baseline": {"tests": len(v006(b)), "outcomes": v006(b), "accepted": baseline_ok, "hypotheses": hypotheses},
        "patched": {"tests": len(p), "failed": sorted(k for k, v in p.items() if v != "passed"), "accepted": patched_ok},
        "verdict": "REGRESSION_ACCEPTED" if baseline_ok and patched_ok else "REGRESSION_NOT_ACCEPTED",
    }
    with open(out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(f"MEALIE_REGRESSION {VERSION} {report['verdict']} baseline_v006={len(v006(b))} patched_total={len(p)}")
    return 0 if report["verdict"] == "REGRESSION_ACCEPTED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
