# Mealie Consistency v006

Configuration version **v006**. Every script, log first line and result file carries `v006`.
Python 3 standard library only. The only password asked for is the admin password, read with hidden input. No password or token is written to disk.

| File | Role | Touches live Mealie? |
|---|---|---|
| `Run-Consistency-v006.ps1` → `run_consistency_v006.py` | shared-resource consistency + rejected-write no-effect checks | **yes** (own household, own new resources) |
| `Run-Mealie-Regression-v006.ps1` → `regression_in_container_v006.sh`, `summarize_junit_v006.py` | Mealie v3.28.0 pytest suite, before/after fix, in a disposable `python:3.14-slim` container | no (SQLite test DB in the container) |
| `Analyze-Evidence-v006.ps1` → `analyze_evidence_v006.py` | regenerate the F04/F05 evidence table from the collection ZIP | no |
| `check_local_v006.py` | local simulation self-check of the runner and summarizer | no |
| `Test-Package-v006.ps1` | verifies `manifest_v006.json` (SHA256 of every file) | no |
| `mealie-v3.28.0-rejected-write-guard-v006.patch` | proposed fix | — |
| `mealie-v3.28.0-regression-tests-v006.patch` | 12 regression tests for Mealie's suite | — |
| `Evidence_Report_v006.md` | findings, root cause, fix, test plan, local-vs-live status | — |
| `results/` | outputs produced while preparing v006 (offline + simulation only) | — |

Outputs:
- `runs/v006-*/review_v006.zip` (`result_v006.json`, `http-events_v006.json`, `run_v006.log`)
- `regression-v006-*.zip` (`regression_v006.json`, JUnit XML, log)
- `evidence-v006-*/`

Exit codes for `Run-Consistency-v006.ps1`:
- 0 for `CONSISTENCY_PASS`.
- 0 for `CONSISTENCY_PASS_WITH_STATUS_MISMATCH` (500 on X1/X2 is expected before the fix), except with `-ExpectPatched`, where it gives 1.
- 1 for `STATE_INCONSISTENCY` or `INCONCLUSIVE`.

Future changes must use v007.
