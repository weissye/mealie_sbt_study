"""Mealie shared-resource consistency and rejected-write no-effect checks, configuration v006.

Scope: two regular users in the admin's own group and household, operating only on
recipes and one shopping list that this run creates. Every resource touched is shared
with and authorized for both users. No cross-household or cross-group request is sent.

What is checked:
  P-steps  authorized writes by either user; both users read back identical, expected state
  X-steps  writes the server should reject (absent reference, invalid body, partially
           invalid bulk); the list as seen by both users, and each user's household item
           count, must be unchanged. The HTTP status is recorded against a status policy.

The X1/X2 absent-reference steps exercise the same code path as the F04 sentinel control.
They are rejection no-effect controls on the actor's own list and are NOT a reproduction
of F04 or F05; a 500 there is reported as a status-policy mismatch only.

Sequential HTTP only, no Provengo, no concurrency. Python 3 standard library only.
The admin password is read with hidden input; passwords and tokens are never written.
"""

import argparse
import datetime
import getpass
import json
import pathlib
import secrets
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile

VERSION = "v006"
SCRIPT = "run_consistency_v006.py"
EXPECTED_SERVER_VERSION = "v3.28.0"
REJECT_OK = {400, 404, 422}
REDACT = {"password", "access_token", "token", "Authorization"}


class Stop(Exception):
    """Abort: setup failure, unknown outcome, or unexpected response on a positive step."""


def now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def redact(obj):
    if isinstance(obj, dict):
        return {k: ("<redacted>" if k in REDACT else redact(v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact(v) for v in obj]
    return obj


class Runner:
    def __init__(self, base: str, run_dir: pathlib.Path, timeout: float = 30.0):
        self.base, self.run_dir, self.timeout = base, run_dir, timeout
        self.tokens: dict[str, str] = {}
        self.events: list[dict] = []
        self.log_lines: list[str] = []
        self.log_file = (run_dir / f"run_{VERSION}.log").open("w", encoding="utf-8")
        self.log(f"MEALIE_CONSISTENCY {VERSION} {SCRIPT} started {now()} base={base}")

    def log(self, msg: str):
        print(msg, flush=True)
        self.log_file.write(msg + "\n")
        self.log_file.flush()

    # ------------------------------------------------------------------ HTTP
    def http(self, actor, method, path, body=None, form=None, timeout=None, auth=True):
        headers = {"Accept": "application/json"}
        data = None
        if form is not None:
            data = urllib.parse.urlencode(form).encode()
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        elif body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        if auth:
            headers["Authorization"] = "Bearer " + self.tokens[actor]
        ev = {"n": len(self.events) + 1, "actor": actor, "method": method, "path": path,
              "request_body": redact(body) if body is not None else ("<form redacted>" if form else None),
              "started": now(), "status": None}
        self.events.append(ev)
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=headers)
        t = timeout or self.timeout
        try:
            with urllib.request.urlopen(req, timeout=t) as h:
                code, raw = h.status, h.read()
        except urllib.error.HTTPError as e:
            code, raw = e.code, e.read()
        except Exception as e:  # timeout / connection: server outcome unknown
            ev.update(error_type=type(e).__name__, finished=now())
            self.log(f"{ev['n']:03d} {actor} {method} {path} -> {type(e).__name__} (outcome unknown)")
            raise Stop(f"{method} {path}: {type(e).__name__}; server outcome unknown") from None
        ev.update(status=code, finished=now())
        try:
            parsed = json.loads(raw) if raw else None
        except ValueError:
            parsed = {"non_json_body": raw[:200].decode("utf-8", "replace")}
        if not (path == "/api/auth/token"):
            ev["response_body"] = redact(parsed) if code >= 400 else None
        self.log(f"{ev['n']:03d} {actor} {method} {path} -> {code}")
        return code, parsed

    def ok(self, actor, method, path, body=None, expect=(200, 201), timeout=None):
        code, data = self.http(actor, method, path, body, timeout=timeout)
        if code not in expect:
            raise Stop(f"{method} {path} returned {code}, expected {sorted(expect)}")
        return data

    def login(self, actor, email, password):
        code, data = self.http(actor, "POST", "/api/auth/token", form={"username": email, "password": password}, auth=False)
        if code != 200 or not (data or {}).get("access_token"):
            raise Stop(f"login for {actor} failed (HTTP {code})")
        self.tokens[actor] = data["access_token"]


def list_state(body: dict) -> dict:
    """Canonical comparable state of a shopping list."""
    return {
        "id": body.get("id"), "name": body.get("name"), "userId": body.get("userId"),
        "groupId": body.get("groupId"), "householdId": body.get("householdId"),
        "updatedAt": body.get("updatedAt"),
        "items": sorted(
            [
                i.get("id"), i.get("quantity"), i.get("checked"), i.get("note"), i.get("updatedAt"),
                sorted([r.get("recipeId"), r.get("recipeQuantity"), r.get("recipeScale")] for r in i.get("recipeReferences", [])),
            ]
            for i in body.get("listItems", [])
        ),
        "recipeReferences": sorted([r.get("recipeId"), r.get("recipeQuantity")] for r in body.get("recipeReferences", [])),
    }


def main(argv=None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--base-url", default="http://127.0.0.1:9925")
    p.add_argument("--admin-email", default="changeme@example.com")
    p.add_argument("--expect-patched", action="store_true",
                   help="treat a 500 on a rejection step as failure (use after applying the v006 fix)")
    p.add_argument("--allow-version", default=EXPECTED_SERVER_VERSION)
    p.add_argument("--password-stdin", action="store_true", help=argparse.SUPPRESS)  # local mock checks only
    p.add_argument("--out", default=None)
    a = p.parse_args(argv)
    base = a.base_url.rstrip("/")
    if not base.startswith(("http://", "https://")):
        p.error("HTTP(S) base URL required")
    root = pathlib.Path(a.out) if a.out else pathlib.Path(__file__).resolve().parent / "runs"
    run_dir = root / f"{VERSION}-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')}"
    run_dir.mkdir(parents=True)
    r = Runner(base, run_dir)
    result = {"version": VERSION, "script": SCRIPT, "base_url": base, "started": now(),
              "execution": "sequential HTTP, logical actor switching, no Provengo, no concurrency",
              "scope": "own household only; resources created by this run; no cross-household or cross-group request",
              "expect_patched": a.expect_patched, "status": "INCONCLUSIVE", "server": {},
              "created": {"users": [], "recipes": [], "lists": [], "items": []},
              "steps": [], "state_checks": [], "status_policy": []}

    def state_check(label, passed, detail=None):
        result["state_checks"].append({"label": label, "pass": bool(passed), "detail": detail})
        r.log(f"    state check {'PASS' if passed else 'FAIL'}: {label}")
        return passed

    def read_list(actor, list_id):
        return r.ok(actor, "GET", f"/api/households/shopping/lists/{list_id}", expect=(200,))

    def household_item_count(actor):
        data = r.ok(actor, "GET", "/api/households/shopping/items?page=1&perPage=-1", expect=(200,))
        return len((data or {}).get("items", []))

    def observe(list_id):
        views = {k: list_state(read_list(k, list_id)) for k in ("A", "B")}
        counts = {k: household_item_count(k) for k in ("A", "B")}
        return views, counts

    try:
        password = sys.stdin.readline().rstrip("\n") if a.password_stdin else getpass.getpass("Admin password: ")
        r.login("ADMIN", a.admin_email, password)
        del password
        admin = r.ok("ADMIN", "GET", "/api/users/self", expect=(200,))
        if admin.get("admin") is not True:
            raise Stop("admin identity not confirmed")
        about = r.ok("ADMIN", "GET", "/api/admin/about", expect=(200,))
        result["server"] = {"version": about.get("version"), "dbType": about.get("dbType"), "buildId": about.get("buildId"),
                            "production": about.get("production")}
        if about.get("version") != a.allow_version:
            raise Stop(f"server version {about.get('version')} != {a.allow_version}")

        # ---------------------------------------------------------- users
        tag = uuid.uuid4().hex[:10]
        users = {}
        for actor in ("A", "B"):
            username = f"sbt_v006_{actor.lower()}_{tag}"
            email, pw = username + "@example.com", secrets.token_urlsafe(32)
            rec = {"actor": actor, "username": username, "status": "CREATE_PENDING"}
            result["created"]["users"].append(rec)
            created = r.ok("ADMIN", "POST", "/api/admin/users", {
                "username": username, "fullName": f"SBT v006 {actor}", "email": email, "password": pw,
                "admin": False, "group": admin["group"], "household": admin["household"],
                "canInvite": False, "canManage": False, "canManageHousehold": False, "canOrganize": True,
            }, expect=(200, 201), timeout=120)
            rec.update(id=created.get("id"), status="CREATED")
            r.login(actor, email, pw)
            del pw
        r.tokens.pop("ADMIN")
        for actor in ("A", "B"):
            users[actor] = r.ok(actor, "GET", "/api/users/self", expect=(200,))
        ua, ub = users["A"], users["B"]
        if not (ua["id"] != ub["id"] and ua["groupId"] == ub["groupId"] and ua["householdId"] == ub["householdId"]):
            raise Stop("fixture guard: users must be distinct and share group and household")
        if ua.get("admin") or ub.get("admin"):
            raise Stop("fixture guard: users must not be admins")
        result["fixture"] = {"groupId": ua["groupId"], "householdId": ua["householdId"],
                             "users": {k: {"id": u["id"], "admin": u.get("admin"), "canOrganize": u.get("canOrganize")} for k, u in users.items()}}

        # ---------------------------------------------------------- recipes
        recipes = {}
        for actor, qty in (("A", 2), ("B", 3)):
            name = f"sbt-v006-{tag}-recipe-{actor.lower()}"
            slug = r.ok(actor, "POST", "/api/recipes", {"name": name}, expect=(201,))
            body = r.ok(actor, "GET", f"/api/recipes/{slug}", expect=(200,))
            body["recipeIngredient"] = [{"quantity": qty, "note": f"sbt-v006-{tag}-ingredient-{actor.lower()}",
                                         "referenceId": str(uuid.uuid4()), "food": None, "unit": None}]
            body = r.ok(actor, "PUT", f"/api/recipes/{slug}", body, expect=(200,))
            other = "B" if actor == "A" else "A"
            seen = r.ok(other, "GET", f"/api/recipes/{slug}", expect=(200,))
            if seen.get("id") != body["id"]:
                raise Stop("recipe not readable by the other household member")
            recipes[actor] = {"id": body["id"], "slug": slug, "qty": qty}
            result["created"]["recipes"].append({"actor": actor, "id": body["id"], "slug": slug})
        RA, RB = recipes["A"]["id"], recipes["B"]["id"]

        # ---------------------------------------------------------- shared list
        lst = r.ok("A", "POST", "/api/households/shopping/lists", {"name": f"sbt-v006-{tag}-shared-list", "extras": {}}, expect=(201,))
        L = lst["id"]
        result["created"]["lists"].append({"actor": "A", "id": L})
        base_list = f"/api/households/shopping/lists/{L}"

        def positive(step_id, actor, desc, method, path, body, expect, verify):
            r.log(f"[{step_id}] {actor}: {desc}")
            code, data = r.http(actor, method, path, body)
            step = {"id": step_id, "kind": "authorized-write", "actor": actor, "description": desc, "status": code}
            result["steps"].append(step)
            if code not in expect:
                raise Stop(f"{step_id}: HTTP {code}, expected {sorted(expect)}")
            views, _ = observe(L)
            state_check(f"{step_id} readers agree", views["A"] == views["B"], None if views["A"] == views["B"] else views)
            ok, detail = verify(views["A"], data)
            state_check(f"{step_id} expected state", ok, detail)
            return data

        def rejection(step_id, actor, desc, method, path, body, allowed=REJECT_OK):
            before_views, before_counts = observe(L)
            r.log(f"[{step_id}] {actor}: {desc}")
            code, data = r.http(actor, method, path, body)
            after_views, after_counts = observe(L)
            step = {"id": step_id, "kind": "rejected-write", "actor": actor, "description": desc, "status": code,
                    "allowed_status": sorted(allowed)}
            result["steps"].append(step)
            unchanged = before_views == after_views
            state_check(f"{step_id} list unchanged for both readers", unchanged,
                        None if unchanged else {"before": before_views, "after": after_views})
            state_check(f"{step_id} household item counts unchanged", before_counts == after_counts,
                        {"before": before_counts, "after": after_counts})
            if code not in allowed:
                result["status_policy"].append({"step": step_id, "observed": code, "allowed": sorted(allowed),
                                                "note": "500 on absent reference matches the F04 symptom class; not counted as reproduction" if code == 500 else None})
                r.log(f"    status policy MISMATCH: {code} not in {sorted(allowed)}")

        def items_by_recipe(view):
            out = {}
            for i in view["items"]:
                for ref in i[5]:
                    out[ref[0]] = i
            return out

        def v_p1(view, _):
            m = items_by_recipe(view)
            ok = m.get(RA, [None, None])[1] == recipes["A"]["qty"] and view["recipeReferences"] == [[RA, 1]]
            return ok, view

        positive("P1", "B", "add A's recipe to A's shared list (single route)", "POST",
                 f"{base_list}/recipe/{RA}", {"recipeIncrementQuantity": 1}, (200,), v_p1)

        def v_p2(view, _):
            m = items_by_recipe(view)
            ok = (m.get(RA, [0, 0])[1] == 2 * recipes["A"]["qty"] and m.get(RB, [0, 0])[1] == recipes["B"]["qty"]
                  and sorted(view["recipeReferences"]) == sorted([[RA, 2], [RB, 1]]))
            return ok, view

        positive("P2", "A", "bulk add both recipes", "POST", f"{base_list}/recipe",
                 [{"recipeId": RB, "recipeIncrementQuantity": 1}, {"recipeId": RA, "recipeIncrementQuantity": 1}], (200,), v_p2)

        manual_note = f"sbt-v006-{tag}-manual"

        def v_p3(view, data):
            notes = [i for i in view["items"] if i[3] == manual_note]
            return len(notes) == 1 and notes[0][1] == 5 and notes[0][2] is False, view

        created_items = positive("P3", "B", "create manual item on the shared list", "POST", "/api/households/shopping/items",
                                 {"shoppingListId": L, "note": manual_note, "quantity": 5}, (201,), v_p3)
        M = created_items["createdItems"][0]["id"]
        result["created"]["items"].append({"actor": "B", "id": M})

        m_body = r.ok("A", "GET", f"/api/households/shopping/items/{M}", expect=(200,))
        m_update = {k: m_body[k] for k in ("shoppingListId", "note", "quantity", "position", "foodId", "labelId", "unitId", "extras", "recipeReferences") if k in m_body}
        m_update["checked"] = True

        def v_p4(view, _):
            notes = [i for i in view["items"] if i[3] == manual_note]
            return len(notes) == 1 and notes[0][2] is True, view

        positive("P4", "A", "check the manual item created by B", "PUT", f"/api/households/shopping/items/{M}", m_update, (200,), v_p4)

        def v_p5(view, _):
            m = items_by_recipe(view)
            ok = m.get(RA, [0, 0])[1] == recipes["A"]["qty"] and sorted(view["recipeReferences"]) == sorted([[RA, 1], [RB, 1]])
            return ok, view

        positive("P5", "B", "remove one unit of A's recipe", "POST", f"{base_list}/recipe/{RA}/delete",
                 {"recipeDecrementQuantity": 1}, (200,), v_p5)

        # ---------------------------------------------------------- rejected writes on the shared list
        absent = str(uuid.uuid4())
        code, _ = r.http("B", "GET", f"/api/recipes/{absent}")
        if code != 404:
            raise Stop(f"absent-recipe precondition not established (GET returned {code})")
        result["absent_recipe_id"] = absent

        rejection("X1", "B", "single add of an absent recipe id (F04 code path, own list)", "POST",
                  f"{base_list}/recipe/{absent}", {"recipeIncrementQuantity": 1})
        rejection("X2", "A", "bulk add: one valid recipe plus one absent id (all-or-nothing)", "POST",
                  f"{base_list}/recipe", [{"recipeId": RB, "recipeIncrementQuantity": 1}, {"recipeId": absent, "recipeIncrementQuantity": 1}])
        rejection("X3", "B", "single add with a non-numeric increment", "POST",
                  f"{base_list}/recipe/{RA}", {"recipeIncrementQuantity": "not-a-number"})
        rejection("X4", "A", "create-bulk: one valid item plus one with a non-numeric quantity", "POST",
                  "/api/households/shopping/items/create-bulk",
                  [{"shoppingListId": L, "note": f"sbt-v006-{tag}-x4-valid", "quantity": 1},
                   {"shoppingListId": L, "note": f"sbt-v006-{tag}-x4-invalid", "quantity": "x"}])
        bad_update = dict(m_update)
        bad_update.pop("shoppingListId", None)
        bad_update["note"] = f"sbt-v006-{tag}-x5-should-not-persist"
        rejection("X5", "B", "item update missing the required shoppingListId", "PUT",
                  f"/api/households/shopping/items/{M}", bad_update)
        rejection("X6", "B", "remove an absent recipe id (no-op; 200 or 4xx acceptable)", "POST",
                  f"{base_list}/recipe/{absent}/delete", {"recipeDecrementQuantity": 1}, allowed={200} | REJECT_OK)

        final, _ = observe(L)
        state_check("final readers agree", final["A"] == final["B"])
        result["final_list_state"] = final["A"]

        state_ok = all(c["pass"] for c in result["state_checks"])
        if not state_ok:
            result["status"] = "STATE_INCONSISTENCY"
        elif result["status_policy"]:
            result["status"] = "CONSISTENCY_PASS_WITH_STATUS_MISMATCH"
        else:
            result["status"] = "CONSISTENCY_PASS"
    except Stop as e:
        result["error"] = str(e)
        if result["state_checks"] and not all(c["pass"] for c in result["state_checks"]):
            result["status"] = "STATE_INCONSISTENCY"
        r.log("STOPPED: " + str(e))
    finally:
        r.tokens.clear()
        result["finished"] = now()
        result["request_count"] = len(r.events)
        (run_dir / f"result_{VERSION}.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        (run_dir / f"http-events_{VERSION}.json").write_text(json.dumps(r.events, indent=2), encoding="utf-8")
        r.log(f"RESULT {VERSION}: {result['status']} requests={len(r.events)} "
              f"state_checks={sum(c['pass'] for c in result['state_checks'])}/{len(result['state_checks'])} "
              f"status_mismatches={len(result['status_policy'])}")
        r.log_file.close()
        with zipfile.ZipFile(run_dir / f"review_{VERSION}.zip", "w", zipfile.ZIP_DEFLATED) as z:
            for n in (f"result_{VERSION}.json", f"http-events_{VERSION}.json", f"run_{VERSION}.log"):
                z.write(run_dir / n, n)
        print("Review ZIP:", run_dir / f"review_{VERSION}.zip")
    if result["status"] == "CONSISTENCY_PASS":
        return 0
    if result["status"] == "CONSISTENCY_PASS_WITH_STATUS_MISMATCH" and not a.expect_patched:
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
