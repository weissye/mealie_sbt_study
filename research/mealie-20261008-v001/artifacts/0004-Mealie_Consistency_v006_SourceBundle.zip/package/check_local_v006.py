"""Local validation for configuration v006 - NO live Mealie involved.

Starts an in-process HTTP simulation of the Mealie endpoints used by
run_consistency_v006.py and runs the runner against it in three modes:

  unpatched  absent recipe -> 500 with no write (shape observed for F04 in preserved evidence)
  patched    absent recipe -> 404 with no write (behaviour expected after the v006 fix)
  faulty     bulk add with an absent recipe writes the valid part, then returns 500
             (an injected fault: the runner's oracle must report STATE_INCONSISTENCY)

The simulation is a test double for the runner's control flow and oracle. It is not
Mealie, it does not reproduce F04/F05, and passing it says nothing about the live server.
"""

import io
import json
import pathlib
import re
import sys
import tempfile
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = "v006"
SCRIPT = "check_local_v006.py"
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run_consistency_v006 as runner  # noqa: E402

ADMIN_PW = "local-admin-password-" + uuid.uuid4().hex


class Sim:
    def __init__(self, mode):
        self.mode = mode
        self.users = {"admin": {"id": str(uuid.uuid4()), "email": "changeme@example.com", "password": ADMIN_PW,
                                "admin": True, "group": "Home", "household": "Family",
                                "groupId": "g1", "householdId": "h1", "canOrganize": True}}
        self.tokens, self.recipes, self.lists, self.items = {}, {}, {}, {}
        self.max_concurrent = 0
        self.active = 0
        self.lock = threading.Lock()
        self.tick = 0

    def ts(self):
        self.tick += 1
        return f"2026-10-08T00:00:{self.tick:02d}.000000Z"

    def list_body(self, lid):
        lst = self.lists[lid]
        return {**lst, "listItems": [dict(i) for i in self.items.values() if i["shoppingListId"] == lid]}

    def add_recipe(self, lid, rid, inc):
        recipe = self.recipes.get(rid)
        ing = recipe["recipeIngredient"][0]
        for it in self.items.values():
            if it["shoppingListId"] == lid and not it["checked"] and it["note"] == ing["note"]:
                it["quantity"] += ing["quantity"] * inc
                it["recipeReferences"][0]["recipeScale"] += inc
                it["updatedAt"] = self.ts()
                break
        else:
            iid = str(uuid.uuid4())
            self.items[iid] = {"id": iid, "shoppingListId": lid, "note": ing["note"], "quantity": ing["quantity"] * inc,
                               "checked": False, "position": 0, "foodId": None, "labelId": None, "unitId": None, "extras": {},
                               "createdAt": self.ts(), "updatedAt": self.ts(),
                               "recipeReferences": [{"recipeId": rid, "recipeQuantity": ing["quantity"], "recipeScale": inc}]}
        refs = self.lists[lid]["recipeReferences"]
        for ref in refs:
            if ref["recipeId"] == rid:
                ref["recipeQuantity"] += inc
                break
        else:
            refs.append({"recipeId": rid, "recipeQuantity": inc})
        self.lists[lid]["updatedAt"] = self.ts()


def handler_for(sim: Sim):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(self, code, body=None):
            # the request is complete once the response is decided: leave the in-flight count
            # before writing, so the client's next request cannot overlap this one spuriously
            with sim.lock:
                if getattr(self, "_inflight", False):
                    sim.active -= 1
                    self._inflight = False
            raw = json.dumps(body).encode() if body is not None else b""
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def body(self):
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b""
            return raw

        def user(self):
            tok = (self.headers.get("Authorization") or "").removeprefix("Bearer ")
            return sim.tokens.get(tok)

        def handle_any(self, method):
            with sim.lock:
                sim.active += 1
                sim.max_concurrent = max(sim.max_concurrent, sim.active)
                self._inflight = True
            try:
                self.route(method)
            finally:
                with sim.lock:
                    if self._inflight:
                        sim.active -= 1
                        self._inflight = False

        def do_GET(self):
            self.handle_any("GET")

        def do_POST(self):
            self.handle_any("POST")

        def do_PUT(self):
            self.handle_any("PUT")

        def route(self, method):
            path = self.path.split("?")[0]
            raw = self.body()
            if path == "/api/auth/token":
                form = dict(x.split("=", 1) for x in raw.decode().split("&"))
                email = form["username"].replace("%40", "@")
                u = next((u for u in sim.users.values() if u["email"] == email and u["password"] == form["password"].replace("%3D", "=")), None)
                if not u:
                    return self.send(401, {"detail": "bad"})
                tok = uuid.uuid4().hex
                sim.tokens[tok] = u
                return self.send(200, {"access_token": tok})
            u = self.user()
            if not u:
                return self.send(401, {"detail": "unauthorized"})
            try:
                data = json.loads(raw) if raw else None
            except ValueError:
                return self.send(422, {"detail": "invalid json"})
            if path == "/api/users/self":
                return self.send(200, {k: v for k, v in u.items() if k != "password"})
            if path == "/api/admin/about":
                return self.send(200, {"version": "v3.28.0", "dbType": "sqlite", "buildId": "local-sim", "production": False})
            if path == "/api/admin/users" and method == "POST":
                uid = str(uuid.uuid4())
                sim.users[uid] = {"id": uid, "email": data["email"], "password": data["password"], "admin": False,
                                  "group": data["group"], "household": data["household"], "groupId": "g1",
                                  "householdId": "h1", "canOrganize": data.get("canOrganize")}
                return self.send(201, {"id": uid})
            if path == "/api/recipes" and method == "POST":
                rid, slug = str(uuid.uuid4()), data["name"]
                sim.recipes[rid] = {"id": rid, "slug": slug, "name": slug, "recipeIngredient": []}
                return self.send(201, slug)
            m = re.fullmatch(r"/api/recipes/([^/]+)", path)
            if m:
                rec = next((r for r in sim.recipes.values() if m.group(1) in (r["slug"], r["id"])), None)
                if not rec:
                    return self.send(404, {"detail": "not found"})
                if method == "PUT":
                    rec["recipeIngredient"] = data["recipeIngredient"]
                return self.send(200, dict(rec))
            if path == "/api/households/shopping/lists" and method == "POST":
                lid = str(uuid.uuid4())
                sim.lists[lid] = {"id": lid, "name": data["name"], "userId": u["id"], "groupId": "g1", "householdId": "h1",
                                  "updatedAt": sim.ts(), "recipeReferences": []}
                return self.send(201, sim.list_body(lid))
            m = re.fullmatch(r"/api/households/shopping/lists/([^/]+)(/recipe(?:/([^/]+))?(/delete)?)?", path)
            if m:
                lid, sub, rid, delete = m.groups()
                if lid not in sim.lists:
                    return self.send(404, {"detail": "not found"})
                if not sub:
                    return self.send(200, sim.list_body(lid))
                if delete:
                    inc = (data or {}).get("recipeDecrementQuantity", 1)
                    for it in list(sim.items.values()):
                        if it["shoppingListId"] == lid and it["recipeReferences"] and it["recipeReferences"][0]["recipeId"] == rid:
                            q = it["recipeReferences"][0]["recipeQuantity"]
                            it["quantity"] -= q * inc
                            it["recipeReferences"][0]["recipeScale"] -= inc
                            it["updatedAt"] = sim.ts()
                    for ref in sim.lists[lid]["recipeReferences"]:
                        if ref["recipeId"] == rid:
                            ref["recipeQuantity"] -= inc
                    return self.send(200, sim.list_body(lid))
                reqs = data if rid is None else [{"recipeId": rid, **(data or {})}]
                for q in reqs:
                    if not isinstance(q.get("recipeIncrementQuantity", 1), (int, float)):
                        return self.send(422, {"detail": "validation"})
                missing = [q for q in reqs if q["recipeId"] not in sim.recipes]
                if missing:
                    if sim.mode == "faulty":
                        for q in reqs:
                            if q["recipeId"] in sim.recipes:
                                sim.add_recipe(lid, q["recipeId"], q.get("recipeIncrementQuantity", 1))
                        return self.send(500, None)
                    return self.send(500 if sim.mode == "unpatched" else 404, None)
                for q in reqs:
                    sim.add_recipe(lid, q["recipeId"], q.get("recipeIncrementQuantity", 1))
                return self.send(200, sim.list_body(lid))
            if path in ("/api/households/shopping/items", "/api/households/shopping/items/create-bulk"):
                if method == "GET":
                    return self.send(200, {"items": list(sim.items.values())})
                batch = data if isinstance(data, list) else [data]
                if any(not isinstance(b.get("quantity", 0), (int, float)) for b in batch):
                    return self.send(422, {"detail": "validation"})
                out = []
                for b in batch:
                    iid = str(uuid.uuid4())
                    sim.items[iid] = {"id": iid, "shoppingListId": b["shoppingListId"], "note": b["note"], "quantity": b["quantity"],
                                      "checked": False, "position": 0, "foodId": None, "labelId": None, "unitId": None,
                                      "extras": {}, "createdAt": sim.ts(), "updatedAt": sim.ts(), "recipeReferences": []}
                    out.append(sim.items[iid])
                return self.send(201, {"createdItems": out, "updatedItems": [], "deletedItems": []})
            m = re.fullmatch(r"/api/households/shopping/items/([^/]+)", path)
            if m and m.group(1) in sim.items:
                it = sim.items[m.group(1)]
                if method == "GET":
                    return self.send(200, dict(it))
                if "shoppingListId" not in data:
                    return self.send(422, {"detail": "shoppingListId required"})
                it.update(checked=data.get("checked", it["checked"]), note=data.get("note", it["note"]), updatedAt=sim.ts())
                return self.send(200, {"createdItems": [], "updatedItems": [dict(it)], "deletedItems": []})
            return self.send(404, {"detail": "no route " + path})

    return H


def run_mode(mode, expect_patched=False):
    sim = Sim(mode)
    srv = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(sim))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    out = tempfile.mkdtemp(prefix=f"sbt-{VERSION}-{mode}-")
    old_stdin, old_stdout = sys.stdin, sys.stdout
    sys.stdin, sys.stdout = io.StringIO(ADMIN_PW + "\n"), io.StringIO()
    try:
        args = ["--base-url", f"http://127.0.0.1:{srv.server_address[1]}", "--password-stdin", "--out", out]
        if expect_patched:
            args.append("--expect-patched")
        code = runner.main(args)
        console = sys.stdout.getvalue()
    finally:
        sys.stdin, sys.stdout = old_stdin, old_stdout
        srv.shutdown()
    run_dir = next(pathlib.Path(out).iterdir())
    result = json.loads((run_dir / f"result_{VERSION}.json").read_text(encoding="utf-8"))
    log = (run_dir / f"run_{VERSION}.log").read_text(encoding="utf-8")
    everything = log + console + (run_dir / f"http-events_{VERSION}.json").read_text(encoding="utf-8") + json.dumps(result)
    leaked = [s for s in [ADMIN_PW] + list(sim.tokens) + [u["password"] for u in sim.users.values()] if s and s in everything]
    return {"mode": mode, "expect_patched": expect_patched, "exit": code, "status": result["status"],
            "state_checks_pass": sum(c["pass"] for c in result["state_checks"]), "state_checks": len(result["state_checks"]),
            "status_mismatches": [s["step"] for s in result["status_policy"]], "requests": result["request_count"],
            "max_concurrent_requests": sim.max_concurrent, "log_first_line": log.splitlines()[0],
            "secrets_found_in_outputs": len(leaked), "review_zip": (run_dir / f"review_{VERSION}.zip").exists()}


def summarizer_cases():
    """Synthetic JUnit files exercise summarize_junit_v006.py acceptance logic (no Mealie)."""
    import subprocess
    cls = "tests.integration_tests.user_household_tests.test_shopping_list_rejected_writes_v006"
    rej, hyp, ctl = ("test_v006_add_recipe_to_other_household_list_single_route",
                     "test_v006_h3_move_own_item_into_other_household_list_is_ignored",
                     "test_v006_control_add_own_recipe_to_own_list")

    def xml(cases):
        body = "".join(f'<testcase classname="{c}" name="{n}">' + ("<failure/>" if o == "f" else "") + "</testcase>"
                       for c, n, o in cases)
        return f"<testsuites><testsuite>{body}</testsuite></testsuites>"

    base_good = [(cls, rej, "f"), (cls, hyp, "f"), (cls, ctl, "p")]
    base_bad = [(cls, rej, "p"), (cls, hyp, "p"), (cls, ctl, "p")]
    pat_good = [(cls, rej, "p"), (cls, hyp, "p"), (cls, ctl, "p"), ("tests.existing", "test_existing", "p")]
    pat_bad = [(cls, rej, "p"), (cls, hyp, "p"), (cls, ctl, "p"), ("tests.existing", "test_existing", "f")]
    out = []
    d = pathlib.Path(tempfile.mkdtemp(prefix=f"sbt-{VERSION}-junit-"))
    for label, b, pt, want in (("good", base_good, pat_good, 0), ("fix-missing", base_bad, pat_good, 1),
                               ("existing-suite-broken", base_good, pat_bad, 1)):
        (d / "b.xml").write_text(xml(b))
        (d / "p.xml").write_text(xml(pt))
        rc = subprocess.run([sys.executable, str(HERE / "summarize_junit_v006.py"), str(d / "b.xml"), str(d / "p.xml"),
                             str(d / "r.json")], capture_output=True).returncode
        out.append({"case": label, "exit": rc, "expected_exit": want, "accepted": rc == want})
    return out


def main():
    print(f"MEALIE_LOCAL_CHECK {VERSION} {SCRIPT}")
    cases = [
        (("unpatched", False), lambda r: r["exit"] == 0 and r["status"] == "CONSISTENCY_PASS_WITH_STATUS_MISMATCH" and r["status_mismatches"] == ["X1", "X2"]),
        (("unpatched", True), lambda r: r["exit"] == 1 and r["status"] == "CONSISTENCY_PASS_WITH_STATUS_MISMATCH"),
        (("patched", True), lambda r: r["exit"] == 0 and r["status"] == "CONSISTENCY_PASS" and not r["status_mismatches"]),
        (("faulty", False), lambda r: r["exit"] == 1 and r["status"] == "STATE_INCONSISTENCY"),
    ]
    results, ok = [], True
    for (mode, ep), expect in cases:
        r = run_mode(mode, ep)
        r["accepted"] = bool(expect(r)) and r["secrets_found_in_outputs"] == 0 and r["max_concurrent_requests"] == 1 \
            and r["log_first_line"].startswith(f"MEALIE_CONSISTENCY {VERSION}") and r["review_zip"]
        ok &= r["accepted"]
        results.append(r)
        print(json.dumps(r))
    junit = summarizer_cases()
    for j in junit:
        print(json.dumps(j))
    ok &= all(j["accepted"] for j in junit)
    report = {"version": VERSION, "script": SCRIPT, "kind": "LOCAL_SIMULATION_ONLY", "live_mealie": False,
              "all_accepted": ok, "runner_cases": results, "summarizer_cases": junit}
    (HERE / f"local_check_result_{VERSION}.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("LOCAL_CHECK", VERSION, "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
