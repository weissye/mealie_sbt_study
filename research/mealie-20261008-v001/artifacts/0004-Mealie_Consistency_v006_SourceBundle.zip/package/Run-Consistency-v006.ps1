# Mealie shared-resource consistency checks, configuration v006 (LIVE: sends HTTP to Mealie).
param(
    [string]$BaseUrl = 'http://127.0.0.1:9925',
    [string]$AdminEmail = 'changeme@example.com',
    [switch]$ExpectPatched
)
$ErrorActionPreference = 'Stop'
$Version = 'v006'
Write-Host "MEALIE_CONSISTENCY $Version launcher Run-Consistency-v006.ps1"
& (Join-Path $PSScriptRoot 'Test-Package-v006.ps1')
$runner = Join-Path $PSScriptRoot 'run_consistency_v006.py'
$runnerArgs = @($runner, '--base-url', $BaseUrl, '--admin-email', $AdminEmail)
if ($ExpectPatched) { $runnerArgs += '--expect-patched' }
if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 @runnerArgs }
elseif (Get-Command python -ErrorAction SilentlyContinue) { & python @runnerArgs }
else { throw 'Python 3 is required.' }
if ($LASTEXITCODE -ne 0) { throw "Consistency $Version not accepted (exit $LASTEXITCODE). Preserve the review_v006.zip printed above." }
Write-Host "MEALIE_CONSISTENCY $Version accepted. Send the review_v006.zip printed above."
