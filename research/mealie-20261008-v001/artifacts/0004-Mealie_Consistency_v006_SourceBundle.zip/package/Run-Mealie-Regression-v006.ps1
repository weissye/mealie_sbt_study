# Mealie test-suite regression for the v006 fix (LOCAL: Mealie's own pytest suite on SQLite
# inside a disposable container; does NOT touch the running Mealie server or its database).
param([string]$Image = 'python:3.14-slim@sha256:caaf356f40667c496d405780745b9ac25771c189a51dfcc42430d531ea09f8a2')
$ErrorActionPreference = 'Stop'
$Version = 'v006'
Write-Host "MEALIE_REGRESSION $Version launcher Run-Mealie-Regression-v006.ps1"
& (Join-Path $PSScriptRoot 'Test-Package-v006.ps1')
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Docker is required.' }
$out = Join-Path $PSScriptRoot ("regression-$Version-" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $out | Out-Null
# Windows PowerShell 5.1 turns redirected native stderr into errors; relax only around docker.
$ErrorActionPreference = 'Continue'
docker run --rm -v "${PSScriptRoot}:/pkg:ro" -v "${out}:/out" $Image sh /pkg/regression_in_container_v006.sh 2>&1 |
    ForEach-Object { "$_" } | Tee-Object -FilePath (Join-Path $out "regression_$Version.log")
$code = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
Compress-Archive -Path (Join-Path $out '*') -DestinationPath "$out.zip"
Write-Host "Regression ZIP: $out.zip"
if ($code -ne 0) { throw "MEALIE_REGRESSION $Version not accepted (exit $code)." }
