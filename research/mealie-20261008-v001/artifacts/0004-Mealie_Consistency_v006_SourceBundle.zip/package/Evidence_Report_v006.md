# Mealie F04/F05 evidence, root cause and remediation — configuration v006

Prepared 2026-10-08. System under test: local Mealie, server-reported `v3.28.0`, `http://127.0.0.1:9925`.
All new artifacts carry `v006`. Nothing delivered under v001–v005 was modified.

## 0. What was verified where

| Level | What | Status |
|---|---|---|
| **A. Offline, here** | Collection ZIP hashes (107/107 match `manifest_v002.json`); 8 live-run ZIPs match their `qualification.json` SHA256; evidence table regenerated from raw receipts and server log (`analyze_evidence_v006.py`) | Done |
| **A. Offline, here** | Mealie source at tag `v3.28.0` (commit `0552eaa4a800…`) read; 6 traceback frames in the preserved server log match tag line numbers exactly | Done |
| **A. Offline, here** | Fix and tests: `git apply --check` on a clean v3.28.0 checkout; `py_compile`; `ruff check`/`ruff format` with Mealie's config | Done |
| **A. Offline, here** | `check_local_v006.py`: runner against an in-process HTTP **simulation** (unpatched / patched / injected-fault modes) + summarizer acceptance logic on synthetic JUnit. Secrets absent from all outputs; max one request in flight | PASS (simulation only) |
| **B. Not run here** | Mealie's own pytest suite with the v006 tests, before and after the fix (`Run-Mealie-Regression-v006.ps1`, Docker). Blocked here: PyPI is not reachable from this workspace | **Pending — your machine** |
| **C. Not run here** | Live Mealie: `Run-Consistency-v006.ps1` | **Pending — your machine** |
| — | PowerShell scripts parsed and `Test-Package-v006.ps1` executed with PowerShell 7.4.6 on Linux, not Windows PowerShell 5.1 | Partial |

Nothing in this report is a new live observation. Every live statement below comes from the preserved 2026-10-05 evidence.

## 1. Inventory

Source: `Mealie_Research_Collection_v002-recovered-20261008-155659-771.zip` (SHA256 `7a6a369a…12ab8`).
The collection's own `summary_v002.json` says `completeness: UNVERIFIED` and that original source paths are lost.

| Requested | Received | Notes |
|---|---|---|
| `Mealie_Shared_Consistency_v005.zip` | yes (1) | read: runner, README, analysis, local validation |
| `review(20261008-121634).zip` — v005 live success | **NO** | the "19 requests / 17 checks" live result is therefore **not verified here** |
| `Mealie_Quantity_Consistency_Engineering_and_Research.docx` | yes (9 copies, 2 binary versions, identical text) | earlier quantity defect family; not F04/F05 |
| `multi-identity-20261005-065704` | yes (several identical copies) | 4 runs, 206 responses; **no server log** |
| `scope-controls-20261005-073218` | yes | 4 runs, 186 responses; server log captured (tail 2000 lines) |
| `qualification.json`, run results, campaign configs | yes | qualification files exist in 2 versions per campaign; commits identical |
| server logs | scope-controls only | truncated: 7 of 12 request lines and 8 of 12 tracebacks for that campaign are present |
| `mealie-openapi.v3.28.0.reviewed.json` | yes (SHA256 `90e19aa7…f292`, matches the pinned value) | |
| Mealie source for each recorded commit | **NO** | see §1.1 |

### 1.1 Commits: study repository ≠ Mealie

`f1f29cf5…` (multi-identity) and `81d33222…` (scope-controls) are commits of **your study/generator repository**, not of Mealie. For scope-controls, `environment.json` records `original_source_commit = f1f29cf5…` and HEAD `81d33222…` at review, and `source-provenance.json` states the snapshot is "not asserted as the exact installed source at live execution".

Mealie source was not in the collection. I used the public tag `v3.28.0` = `0552eaa4a80031b8572849cca0ed95d07f1be001`. The tie between this tag and your running container rests on the server-reported version and on six traceback frames matching tag line numbers (134, 219, 258, 272, 342, 449). There is no image digest. The v006 live runner records `buildId` and `dbType` from `/api/admin/about` to close this gap.

### 1.2 Still missing — please provide

1. `review(20261008-121634).zip` (v005 live evidence).
2. Docker image digest of `mealie-sbt-study-mealie-1`: `docker inspect --format '{{.Image}} {{index .Config.Labels "org.opencontainers.image.revision"}}' mealie-sbt-study-mealie-1`.
3. DB engine of the running instance (or let the v006 runner record it).
4. Untruncated server log for multi-identity and scope-controls (if `docker logs` still holds them), for the 5 F04 manifestations without a traceback.

## 2. Evidence table

Full row-level table: `results/evidence_table_v006.md` / `.json`, which is regenerable with `Analyze-Evidence-v006.ps1`. Summary:

| | **F04** | **F05** |
|---|---|---|
| Source | multi-identity (separate ×2), scope-controls/reference-controls ×2 | scope-controls/household-controls ×2 |
| Server version | v3.28.0 (server check) | v3.28.0 |
| Study commit | f1f29cf5 (multi-identity); 81d33222 recorded, f1f29cf5 at execution (scope) | 81d33222 recorded, f1f29cf5 at execution |
| Mealie source | tag v3.28.0 / 0552eaa4 (inferred, §1.1) | same |
| Request | `POST /lists/{own list}/recipe/{recipe}` with a recipe from another **group** (8) or an absent UUID (4) | `POST /lists/{other household's list}/recipe/{own recipe}`, same group, regular users (all role flags false) |
| Response | 500 ×12 | 500 ×4 |
| Server exception | `UnexpectedNone: Recipe not found` at `shopping_lists.py:342` (4 tracebacks in log; 8 not captured) | `AttributeError: 'NoneType' object has no attribute 'list_items'` at `shopping_lists.py:134`, reached via `bulk_create_items:219` (4/4 captured) |
| State before → after (target list) | items 1→1, same IDs, list refs unchanged (12/12) | items **2→3** (4/4); one new item, qty 2, references the actor's recipe; list-level refs unchanged (2→2) |
| Timing | — | new item `createdAt` is 0.12–0.17 s **before** the 500 line is logged (4/4) |
| Intervening steps | none | none between the failed request and the owner's readback (receipts and log) |
| Actor's read access to list | own list (200) | **404** immediately before the write |
| Distinct defects | **1** (unhandled missing-recipe exception) | **1** (write committed before list-scope resolution) |
| Conclusion | Controlled-rejection defect: a missing or other-group reference yields 500 instead of 404. No state change. | Partial cross-household write: the failing request persists an item in a list the actor cannot read, then fails with 500. |
| Limitations | 8 of 12 without a traceback; no reset/replay; no minimal standalone reproduction | 2 samples, one campaign, one seed; no reset/replay; fix not yet executed; "authorization" rests on the policy evidence in §3.3 |

F04 and F05 are separate mechanisms, not one defect. Their 500s must not be added together: F04 has 12 manifestations of 1 defect, F05 has 4 manifestations of 1 defect.

## 3. Facts, hypotheses, labels

### 3.1 Documented facts (preserved evidence + source)
- 16 HTTP 500s across 8 runs / 392 responses: 12 F04 and 4 F05. The `shared` multi-identity runs have none.
- F04 rows: no item added, removed or changed on the target list.
- F05 rows: exactly one item added. It has the actor's recipe reference, `createdAt` precedes the logged 500, and the owner reads it back.
- In v3.28.0, `ShoppingListItem.household_id` is an association proxy through the parent list (`db/models/household/shopping_list.py`). Repository inserts (`create_many`) do not filter by household. Reads (`get_one`, `page_all`) do.
- Each repository write commits immediately (`repository_generic.py` `create`/`create_many`/`update`/`update_many`). The request session (`db_setup.generate_session`) only closes, so there is no request-level transaction.

### 3.2 Root cause (source + traceback, not yet replayed)
**F05.** `add_recipe_ingredients_to_list` never checks that `list_id` is visible to the caller. `bulk_create_items` then looks for merge candidates through the household-scoped item repository and sees none. That explains why a new item appears instead of a merged quantity. It then commits the new item (`create_many`). Only afterwards does `remove_unused_recipe_references` fetch the list through the scoped repository, get `None`, and raise `AttributeError`. The commit has already happened.

**F04.** The recipe lookup is group-scoped (`get_shopping_list_items_from_recipe`), so an other-group recipe is indistinguishable from an absent one. `UnexpectedNone` has no HTTP mapping and becomes 500. Recipes are resolved before any write, which is consistent with the observed absence of state change.

### 3.3 Effective policy (evidence that the F05 write is unintended)
- The actor gets 404 on `GET` of the same list.
- Mealie v3.28.0's own tests `test_shopping_list_items_cannot_update_other_household_items` and `…cannot_delete_other_household_items` require that cross-household item writes leave the item unchanged. No equivalent test exists for create or add-recipe.
- Mealie's contributor guide: "Do route handlers properly validate group/household ownership before operations?"

### 3.4 Hypotheses (not observed)
- **H2.** `POST /api/households/shopping/items` and `/items/create-bulk` with another household's `shoppingListId` go through the same `bulk_create_items` path, so the same write-then-500 is expected.
- **H3.** `PUT /api/households/shopping/items/{own item}` with another household's `shoppingListId` may move the item. `update_many` filters by the item's current household, then applies the new parent.

Both are covered by v006 tests in Mealie's suite (test DB only). Their baseline outcome will confirm or refute them. They are not sent to the live server.

### 3.5 Script labels
- `unauthorized_changes` (scope `qualification.json`) is a label applied by the oracle. The F05 conclusion rests on §3.1–3.3, not on the label.
- `IDENTITY_CANDIDATE`, `REPRODUCED_SERVER_ERROR_WITH_FOREIGN_RECIPE_REFERENCE` and `HTTP_POLICY_MISMATCH` are runner/oracle labels.
- `unauthorized_mutation_demonstrated: false` in multi-identity is correct for that campaign: its F04 rows show no mutation.

## 4. Fix (`mealie-v3.28.0-rejected-write-guard-v006.patch`)

The principle is to resolve every target list through the caller-scoped repository **before the first write**.

- `ShoppingListService.require_accessible_lists(ids)` raises `NoEntryFound` if any list is not visible.
- `add_recipe_ingredients_to_list`: guard first, then resolve recipes.
- `bulk_create_items`: guard on all target lists. A mixed bulk is rejected as a whole.
- `bulk_update_items`: updates whose target list is invisible are dropped before any write. This keeps the existing upstream contract (foreign updates → 200, no change) and blocks H3.
- Missing recipe or list now raises `NoEntryFound` instead of `UnexpectedNone`. The controllers map it to **404** for add-recipe, remove-recipe and item create.

The patch is not a full transactional fix. Other multi-step service operations still commit per repository call. A request-level unit of work would be a larger upstream change. The patch applies to v3.28.0. Upstream `mealie-next` (9c71e29) has not changed this logic but needs a trivial rebase (imports).

## 5. Regression tests (`mealie-v3.28.0-regression-tests-v006.patch`)

The new file is `tests/integration_tests/user_household_tests/test_shopping_list_rejected_writes_v006.py`, with 12 tests. Each rejection test snapshots the target list through its **owner** (item IDs, quantities, notes, checked, `updatedAt`, item and list recipe refs), sends the rejected request, requires 404, and compares the snapshots.

| Test | Covers | Baseline expectation (no fix) |
|---|---|---|
| add_recipe_to_other_household_list_single_route / _bulk_route | F05 | fail |
| create_item_on_other_household_list | H2 | fail |
| mixed_bulk_create_is_all_or_nothing | H2, atomic precheck | fail |
| remove_recipe_from_other_household_list | 500→404 (no write today) | fail |
| h3_move_own_item_into_other_household_list_is_ignored | H3 | reported separately: fail = H3 confirmed |
| add_missing_recipe_to_own_list / add_other_group_recipe_to_own_list | F04 | fail (500) |
| bulk_add_with_one_missing_recipe_is_all_or_nothing | F04, atomicity | fail |
| control_add_own_recipe_to_own_list / control_same_household_shared_list / control_cross_household_recipe_on_own_list | authorized writes unaffected | pass |

After the fix, all v006 tests plus the existing `test_group_shopping_lists.py`, `test_group_shopping_list_items.py` and `test_repository_factory.py` must pass. The acceptance rule is in `summarize_junit_v006.py`.

## 6. Live consistency extension v006 (authorized shared resources only)

`run_consistency_v006.py` uses two regular users in the admin's own household, on recipes and one list that the run creates. **No cross-household or cross-group request is sent.**

- **P1–P5, authorized writes by either user:** single and bulk recipe add, manual item create by the other user, check by the other user, recipe removal. Both users must read back identical state, and it must match the expected quantities and refs.
- **X1–X6, writes that must have no effect:**
  - X1: absent recipe, single route
  - X2: valid + absent recipe in one bulk request
  - X3: non-numeric increment
  - X4: create-bulk with one invalid item
  - X5: update without the required `shoppingListId`
  - X6: removal of an absent reference (a no-op)

  For each, the list as seen by **both** users and each user's household item count must be unchanged. The status is checked against {400, 404, 422}; X6 also allows 200.
- **Expected on the current server:** `CONSISTENCY_PASS_WITH_STATUS_MISMATCH`, with X1 and X2 returning 500. That is the F04 code path on an authorized list, reported only as a status mismatch and **not as an F04 reproduction**. With `-ExpectPatched` after the fix: `CONSISTENCY_PASS`.
- About 103 sequential requests. There is no Provengo and no concurrency. Created users, recipes and the list are left in place and recorded in `result_v006.json`.

## 7. Reporting note

F05 is an integrity issue across a household boundary. It needs an authenticated user in the same group who knows the target list's UUID. If you intend to report it upstream, Mealie's GitHub private security advisory channel fits better than a public issue.
