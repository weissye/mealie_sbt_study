# Mealie Consistency v006 - source bundle

Configuration version v006. Repackaging only: no file content differs from the delivered v006 package
(`Mealie_Consistency_v006.zip`, SHA256 B6E3AA5E38B1D2A6A91E0CAEAA31F28DC457DEC9F1FDB55AA2060A598A712D99).

| Path | Content |
|---|---|
| `Mealie_Consistency_v006.zip` | the delivered v006 package, byte-identical |
| `package/` | the same package extracted: `run_consistency_v006.py`, launchers (`*.ps1`), `regression_in_container_v006.sh`, `summarize_junit_v006.py`, `analyze_evidence_v006.py`, `check_local_v006.py`, both patches, report, `manifest_v006.json`, `results/` |
| `mealie-v3.28.0-patched-files/` | full Mealie files after applying both v006 patches to tag v3.28.0 (commit 0552eaa4a80031b8572849cca0ed95d07f1be001), including the test file `test_shopping_list_rejected_writes_v006.py` |
| `mealie-v3.28.0-original-files/` | the two unmodified v3.28.0 files the fix changes, for diffing |
| `BUNDLE_MANIFEST_v006.json` | SHA256 of every file in this bundle; `package/` entries cross-checked against `manifest_v006.json` |

Verification: `package/Test-Package-v006.ps1` checks the package files. The patched files equal
`git apply` of `package/mealie-v3.28.0-*-v006.patch` on tag v3.28.0.

Verified results for this code (2026-10-08, on the researcher's machine):
- Mealie regression `REGRESSION_ACCEPTED` (`regression-v006-20261008-182957.zip`): baseline 9 rejection tests failed as predicted, 3 controls passed, H3 supported; patched 84/84 passed.
- Live `run_consistency_v006.py`, two runs: `CONSISTENCY_PASS_WITH_STATUS_MISMATCH`, 103 requests, 23/23 state checks, X1/X2 = 500; server buildId 0552eaa4..., SQLite.
