"""
v006 regression tests: a rejected shopping-list write must leave no state change.

Study configuration version: v006 (Mealie SBT study, F04/F05 remediation).

F05 (preserved evidence, scope-controls-20261005-073218): a same-group, other-household
add-recipe request returned HTTP 500 after `bulk_create_items` had already committed a new
item to the other household's list. F04: a missing or other-group recipe reference returned
HTTP 500 instead of a controlled 404.

Each rejection test snapshots the target list through its owner, sends the request as a
user that must be rejected, requires a 404 (or, for item updates, the existing upstream
"ignored, 200 with no updated items" contract), and compares the owner's readback with the
snapshot. Positive controls confirm that the guard does not block authorized writes.
"""

from uuid import uuid4

from fastapi.testclient import TestClient
from pydantic import UUID4

from mealie.schema.household.group_shopping_list import ShoppingListItemCreate, ShoppingListOut, ShoppingListSave
from mealie.schema.recipe.recipe import Recipe
from tests.utils import api_routes
from tests.utils.factories import random_string
from tests.utils.fixture_schemas import TestUser

VERSION = "v006"


def _create_recipe(user: TestUser, ingredient_quantity: float = 2) -> Recipe:
    return user.repos.recipes.create(
        Recipe(
            user_id=user.user_id,
            group_id=user.group_id,
            name=f"sbt-{VERSION}-{random_string(10)}",
            recipe_ingredient=[{"note": f"sbt-{VERSION}-{random_string(8)}", "quantity": ingredient_quantity}],
        )
    )


def _create_list(user: TestUser, recipe: Recipe | None = None, manual_items: int = 1) -> ShoppingListOut:
    repos = user.repos
    shopping_list = repos.group_shopping_lists.create(
        ShoppingListSave(name=f"sbt-{VERSION}-{random_string(10)}", group_id=user.group_id, user_id=user.user_id)
    )
    for _ in range(manual_items):
        repos.group_shopping_list_item.create(
            ShoppingListItemCreate(shopping_list_id=shopping_list.id, note=random_string(10), quantity=3)
        )
    out = repos.group_shopping_lists.get_one(shopping_list.id)
    assert out is not None
    return out


def _snapshot(user: TestUser, list_id: UUID4) -> dict:
    """Owner-visible state of a list that a rejected request must not change."""
    shopping_list = user.repos.group_shopping_lists.get_one(list_id)
    assert shopping_list is not None, "owner can no longer read its own list"
    return {
        "id": shopping_list.id,
        "user_id": shopping_list.user_id,
        "household_id": shopping_list.household_id,
        "name": shopping_list.name,
        "items": sorted(
            (
                str(item.id),
                item.quantity,
                item.note,
                item.checked,
                str(item.updated_at),
                tuple(
                    sorted(
                        (str(ref.recipe_id), ref.recipe_quantity, ref.recipe_scale) for ref in item.recipe_references
                    )
                ),
            )
            for item in shopping_list.list_items
        ),
        "recipe_references": sorted(
            (str(ref.recipe_id), ref.recipe_quantity) for ref in shopping_list.recipe_references
        ),
    }


def _assert_rejected_without_change(response, owner: TestUser, list_id: UUID4, before: dict) -> None:
    assert response.status_code == 404, f"expected 404, observed {response.status_code}: {response.text}"
    assert _snapshot(owner, list_id) == before


# ---------------------------------------------------------------------------
# F05: other household, same group (list not visible to the actor)


def test_v006_add_recipe_to_other_household_list_single_route(
    api_client: TestClient, unique_user: TestUser, h2_user: TestUser
):
    victim_recipe = _create_recipe(h2_user)
    victim_list = _create_list(h2_user)
    api_client.post(
        api_routes.households_shopping_lists_item_id_recipe_recipe_id(victim_list.id, victim_recipe.id),
        headers=h2_user.token,
    ).raise_for_status()
    actor_recipe = _create_recipe(unique_user)
    before = _snapshot(h2_user, victim_list.id)

    # the actor cannot read the list ...
    assert (
        api_client.get(
            api_routes.households_shopping_lists_item_id(victim_list.id), headers=unique_user.token
        ).status_code
        == 404
    )

    # ... so a write to it must be rejected the same way, with nothing persisted
    response = api_client.post(
        api_routes.households_shopping_lists_item_id_recipe_recipe_id(victim_list.id, actor_recipe.id),
        json={"recipeIncrementQuantity": 1},
        headers=unique_user.token,
    )
    _assert_rejected_without_change(response, h2_user, victim_list.id, before)


def test_v006_add_recipe_to_other_household_list_bulk_route(
    api_client: TestClient, unique_user: TestUser, h2_user: TestUser
):
    victim_list = _create_list(h2_user)
    actor_recipe = _create_recipe(unique_user)
    before = _snapshot(h2_user, victim_list.id)

    response = api_client.post(
        api_routes.households_shopping_lists_item_id_recipe(victim_list.id),
        json=[{"recipeId": str(actor_recipe.id), "recipeIncrementQuantity": 1}],
        headers=unique_user.token,
    )
    _assert_rejected_without_change(response, h2_user, victim_list.id, before)


def test_v006_create_item_on_other_household_list(api_client: TestClient, unique_user: TestUser, h2_user: TestUser):
    victim_list = _create_list(h2_user)
    before = _snapshot(h2_user, victim_list.id)
    payload = {"shoppingListId": str(victim_list.id), "note": random_string(10), "quantity": 2}

    response = api_client.post(api_routes.households_shopping_items, json=payload, headers=unique_user.token)
    _assert_rejected_without_change(response, h2_user, victim_list.id, before)

    response = api_client.post(
        api_routes.households_shopping_items_create_bulk, json=[payload], headers=unique_user.token
    )
    _assert_rejected_without_change(response, h2_user, victim_list.id, before)


def test_v006_mixed_bulk_create_is_all_or_nothing(api_client: TestClient, unique_user: TestUser, h2_user: TestUser):
    own_list = _create_list(unique_user)
    victim_list = _create_list(h2_user)
    own_before = _snapshot(unique_user, own_list.id)
    victim_before = _snapshot(h2_user, victim_list.id)

    response = api_client.post(
        api_routes.households_shopping_items_create_bulk,
        json=[
            {"shoppingListId": str(own_list.id), "note": random_string(10), "quantity": 1},
            {"shoppingListId": str(victim_list.id), "note": random_string(10), "quantity": 1},
        ],
        headers=unique_user.token,
    )
    _assert_rejected_without_change(response, h2_user, victim_list.id, victim_before)
    assert _snapshot(unique_user, own_list.id) == own_before


def test_v006_remove_recipe_from_other_household_list(api_client: TestClient, unique_user: TestUser, h2_user: TestUser):
    victim_recipe = _create_recipe(h2_user)
    victim_list = _create_list(h2_user)
    api_client.post(
        api_routes.households_shopping_lists_item_id_recipe_recipe_id(victim_list.id, victim_recipe.id),
        headers=h2_user.token,
    ).raise_for_status()
    before = _snapshot(h2_user, victim_list.id)

    response = api_client.post(
        api_routes.households_shopping_lists_item_id_recipe_recipe_id_delete(victim_list.id, victim_recipe.id),
        json={"recipeDecrementQuantity": 1},
        headers=unique_user.token,
    )
    _assert_rejected_without_change(response, h2_user, victim_list.id, before)


def test_v006_h3_move_own_item_into_other_household_list_is_ignored(
    api_client: TestClient, unique_user: TestUser, h2_user: TestUser
):
    """H3 (source-level hypothesis): an update may re-parent an own item into a list the actor cannot read."""
    own_list = _create_list(unique_user)
    victim_list = _create_list(h2_user)
    own_before = _snapshot(unique_user, own_list.id)
    victim_before = _snapshot(h2_user, victim_list.id)
    item = own_list.list_items[0]
    payload = {"shoppingListId": str(victim_list.id), "note": item.note, "quantity": item.quantity, "checked": False}

    response = api_client.put(
        api_routes.households_shopping_items_item_id(item.id), json=payload, headers=unique_user.token
    )
    assert response.status_code == 200, response.text
    assert response.json()["updatedItems"] == []
    assert _snapshot(unique_user, own_list.id) == own_before
    assert _snapshot(h2_user, victim_list.id) == victim_before


# ---------------------------------------------------------------------------
# F04: unavailable recipe reference on the actor's own list


def test_v006_add_missing_recipe_to_own_list(api_client: TestClient, unique_user: TestUser):
    own_list = _create_list(unique_user)
    before = _snapshot(unique_user, own_list.id)

    response = api_client.post(
        api_routes.households_shopping_lists_item_id_recipe_recipe_id(own_list.id, uuid4()),
        json={"recipeIncrementQuantity": 1},
        headers=unique_user.token,
    )
    _assert_rejected_without_change(response, unique_user, own_list.id, before)


def test_v006_add_other_group_recipe_to_own_list(api_client: TestClient, unique_user: TestUser, g2_user: TestUser):
    foreign_recipe = _create_recipe(g2_user)
    own_list = _create_list(unique_user)
    before = _snapshot(unique_user, own_list.id)

    response = api_client.post(
        api_routes.households_shopping_lists_item_id_recipe_recipe_id(own_list.id, foreign_recipe.id),
        json={"recipeIncrementQuantity": 1},
        headers=unique_user.token,
    )
    _assert_rejected_without_change(response, unique_user, own_list.id, before)


def test_v006_bulk_add_with_one_missing_recipe_is_all_or_nothing(api_client: TestClient, unique_user: TestUser):
    own_recipe = _create_recipe(unique_user)
    own_list = _create_list(unique_user)
    before = _snapshot(unique_user, own_list.id)

    response = api_client.post(
        api_routes.households_shopping_lists_item_id_recipe(own_list.id),
        json=[
            {"recipeId": str(own_recipe.id), "recipeIncrementQuantity": 1},
            {"recipeId": str(uuid4()), "recipeIncrementQuantity": 1},
        ],
        headers=unique_user.token,
    )
    _assert_rejected_without_change(response, unique_user, own_list.id, before)


# ---------------------------------------------------------------------------
# Positive controls: authorized writes are unaffected by the guard


def test_v006_control_add_own_recipe_to_own_list(api_client: TestClient, unique_user: TestUser):
    own_recipe = _create_recipe(unique_user, ingredient_quantity=2)
    own_list = _create_list(unique_user, manual_items=0)

    response = api_client.post(
        api_routes.households_shopping_lists_item_id_recipe_recipe_id(own_list.id, own_recipe.id),
        json={"recipeIncrementQuantity": 1},
        headers=unique_user.token,
    )
    assert response.status_code == 200
    after = _snapshot(unique_user, own_list.id)
    assert len(after["items"]) == 1 and after["items"][0][1] == 2
    assert after["recipe_references"] == [(str(own_recipe.id), 1)]


def test_v006_control_same_household_shared_list(api_client: TestClient, user_tuple: list[TestUser]):
    """Two users of one household may both write to a list either of them created."""
    owner, other = user_tuple
    shared_list = _create_list(owner, manual_items=0)
    payload = {"shoppingListId": str(shared_list.id), "note": random_string(10), "quantity": 2}

    response = api_client.post(api_routes.households_shopping_items, json=payload, headers=other.token)
    assert response.status_code == 201
    after = _snapshot(owner, shared_list.id)
    assert [item[2] for item in after["items"]] == [payload["note"]]


def test_v006_control_cross_household_recipe_on_own_list(
    api_client: TestClient, unique_user: TestUser, h2_user: TestUser
):
    """Group-visible recipe from another household on the actor's own list is expected sharing."""
    other_household_recipe = _create_recipe(h2_user, ingredient_quantity=2)
    own_list = _create_list(unique_user, manual_items=0)

    response = api_client.post(
        api_routes.households_shopping_lists_item_id_recipe_recipe_id(own_list.id, other_household_recipe.id),
        json={"recipeIncrementQuantity": 1},
        headers=unique_user.token,
    )
    assert response.status_code == 200
    assert _snapshot(unique_user, own_list.id)["recipe_references"] == [(str(other_household_recipe.id), 1)]
