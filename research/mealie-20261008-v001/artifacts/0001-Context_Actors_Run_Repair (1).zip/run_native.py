"""Native Provengo actor acceptance against an explicitly shared local fixture."""
import argparse
from collections import Counter
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import zipfile


def save_review(run, generator, bundle, result):
    (run/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    for name in ['run_native.py','verify_archive.py','Run-Context-Actors.ps1','bootstrap-source.zip']:
        source=bundle/name
        if source.is_file():shutil.copy2(source,run/name)
    shutil.copytree(bundle/'fixtures',run/'fixtures',dirs_exist_ok=True)
    with zipfile.ZipFile(run/'generator-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for source in sorted((generator/'generator_v56').rglob('*.py')):
            archive.write(source,source.relative_to(generator))
    temporary=run/'review.zip.tmp'
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as archive:
        for source in sorted(run.rglob('*')):
            if source.is_file() and source.name not in ['review.zip','review.zip.tmp']:
                archive.write(source,source.relative_to(run))
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:raise ValueError('Review archive integrity check failed')
    temporary.replace(run/'review.zip')
    (bundle/'last-review-path.txt').write_text(str(run/'review.zip'),encoding='utf-8')
    print('Review ZIP:',run/'review.zip',flush=True)


def run_provengo(command, **options):
    if os.name=='nt' and Path(command[0]).suffix.lower() in ('.bat','.cmd'):
        # subprocess supplies cmd.exe and its outer quoting in shell mode.
        # Passing a quoted /c string as a list caused escaped quotes on Windows.
        return subprocess.run(subprocess.list2cmdline(command),shell=True,**options)
    return subprocess.run(command,**options)


class SharedFixture(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def perform(self):
        actor={'Bearer fixture-token-A':'A','Bearer fixture-token-B':'B'}.get(self.headers.get('Authorization'))
        raw=self.rfile.read(int(self.headers.get('Content-Length','0')))
        body=json.loads(raw) if raw else None
        code=200
        if not actor:
            code=401; result={'detail':'fixture token missing'}
        elif self.command=='POST' and self.path=='/resources':
            identity='fixture-'+str(len(self.server.resources)+1)
            result=dict(body,id=identity);self.server.resources[identity]=result;code=201
            self.server.creators[identity]=actor
        else:
            parts=self.path.strip('/').split('/')
            identity=parts[1] if len(parts)>1 else ''
            if identity not in self.server.resources:
                code=404;result={'detail':'fixture resource absent'}
            elif self.command=='PATCH' and len(parts)==2:
                self.server.resources[identity].update(body);result=self.server.resources[identity]
            elif self.command=='GET' and len(parts)==2:
                result=self.server.resources[identity]
            elif self.command=='POST' and len(parts)==3 and parts[2]=='action':
                # Both actors have explicit access; the fixture action preserves state.
                result=self.server.resources[identity]
            else:
                code=400;result={'detail':'unsupported fixture request'}
        self.server.receipts.append({'actor':actor,'method':self.command,'path':self.path,'status':code})
        payload=json.dumps(result).encode();self.send_response(code)
        self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(payload)))
        self.end_headers();self.wfile.write(payload)

    do_GET=perform
    do_POST=perform
    do_PATCH=perform


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--generator-root',type=Path,required=True)
    parser.add_argument('--seed',type=int,default=20261007)
    parser.add_argument('--provengo-jar',type=Path,help='Use an existing Provengo JAR instead of the CLI')
    args=parser.parse_args();generator=args.generator_root.resolve();bundle=Path(__file__).resolve().parent
    if not (generator/'generator_v56').is_dir():raise SystemExit('Generator root must contain generator_v56')
    # Frozen payload deltas contain only changed modules, not a full package.
    # Restore absent source files; never replace installed modules or actor changes.
    restored=[]
    snapshot=bundle/'bootstrap-source.zip'
    if snapshot.is_file():
        with zipfile.ZipFile(snapshot) as archive:
            for name in archive.namelist():
                target=(generator/name).resolve()
                if not target.is_relative_to(generator) or not name.startswith('generator_v56/'):
                    raise SystemExit('Invalid bootstrap source path')
                if name.endswith('.py') and not target.exists():
                    target.parent.mkdir(parents=True,exist_ok=True)
                    with target.open('xb') as output:output.write(archive.read(name))
                    restored.append(name)
    run=generator/'runs'/('context-actors-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    run.mkdir(parents=True);project=run/'project'
    result={'status':'NOT_ACCEPTED','fixture_only':True,'sut_requests':0,'native_provengo_executed':False,
            'execution':'logical interleaving with sequential HTTP','seed':args.seed,
            'restored_missing_source_files':restored}
    if args.provengo_jar:
        jar=args.provengo_jar.resolve()
        java=shutil.which('java')
        if not jar.is_file() or not java:
            result.update(status='BLOCKED_PROVENGO_UNAVAILABLE',error='Existing JAR file and Java are required')
            save_review(run,generator,bundle,result)
            print(result['status']);return 1
        runner=java
        runner_command=[java,'-jar',str(jar)]
    else:
        runner=shutil.which('provengo') or shutil.which('provengo.bat')
        if not runner:
            result.update(status='BLOCKED_PROVENGO_UNAVAILABLE',error='Provengo not on PATH; supply --provengo-jar')
            save_review(run,generator,bundle,result)
            print(result['status']);return 1
        runner_command=[runner]
        if os.name=='nt' and Path(runner).suffix.lower() in ('.bat','.cmd'):
            jars=[p for p in Path(runner).parent.glob('*')
                  if p.is_file() and p.suffix.lower()=='.jar' and 'provengo' in p.name.lower()]
            java=shutil.which('java')
            if java and len(jars)==1:runner_command=[java,'-jar',str(jars[0])]
    # Single-threaded HTTPServer: logical interleaving only, no simultaneous requests.
    server=HTTPServer(('127.0.0.1',0),SharedFixture)
    server.resources={};server.creators={};server.receipts=[]
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        version=run_provengo(runner_command+['--version'],capture_output=True,text=True,errors='replace',timeout=30)
        (run/'provengo-version.txt').write_text(version.stdout+version.stderr,encoding='utf-8')
        # Some frozen project packages contain cli.py but no __main__.py.
        # Use the same central CLI entry point without requiring that wrapper.
        command=[sys.executable,'-B','-c',
                 'from generator_v56.cli import main; raise SystemExit(main())','context-generate',
                 '--openapi',str(bundle/'fixtures/openapi.json'),'--output',str(project/'spec/js'),
                 '--name','fixture','--base-url','http://127.0.0.1:'+str(server.server_port),
                 '--resource','/resources','--instances-per-entity','2','--seed',str(args.seed),
                 '--observed-action','POST:/resources/{id}/action',
                 '--actor-config',str(bundle/'fixtures/actors.json')]
        generation=subprocess.run(command,cwd=generator,capture_output=True,text=True,timeout=30)
        (run/'generation.log').write_text(generation.stdout+generation.stderr,encoding='utf-8')
        if generation.returncode:
            raise ValueError('Central generator failed; see generation.log')
        env=os.environ.copy();env['SBT_ACTOR_A_TOKEN']='fixture-token-A';env['SBT_ACTOR_B_TOKEN']='fixture-token-B'
        native_command=runner_command+['run',str(project)]
        native=run_provengo(native_command,env=env,capture_output=True,text=True,errors='replace',timeout=90)
        log=native.stdout+'\n'+native.stderr;(project/'native-run.log').write_text(log,encoding='utf-8')
        result.update(native_provengo_executed=True,native_exit=native.returncode,
                      fixture_requests=server.receipts,resource_creators=server.creators)
        actions=Counter((r['actor'],r['path']) for r in server.receipts if r['method']=='POST' and r['path'].endswith('/action'))
        expected=Counter((actor,'/resources/'+identity+'/action') for actor in ['A','B'] for identity in server.resources)
        observations=[json.loads(line.split('OBSERVATION_EVIDENCE ',1)[1])
                      for line in log.splitlines() if 'OBSERVATION_EVIDENCE ' in line]
        result['observations']=observations
        reasons=[]
        if native.returncode!=0:reasons.append('Native run failed')
        if len(server.resources)!=2 or Counter(server.creators.values())!=Counter({'A':1,'B':1}):reasons.append('Lifecycle actors incorrect')
        if actions!=expected:reasons.append('Expected actor/resource combinations not executed')
        if len(server.receipts)!=18 or any(r['status'] not in (200,201) for r in server.receipts):reasons.append('Fixture request coverage differs')
        if len(observations)!=4 or Counter(o.get('actor') for o in observations)!=Counter({'A':2,'B':2}):reasons.append('Actor observation coverage differs')
        if not all(o.get('observationsComplete') and o.get('contractStatusValid') and
                   len(o.get('readbacks',[]))==1 and o['readbacks'][0].get('identityMatches') and
                   o['readbacks'][0].get('expectedMatches') for o in observations):reasons.append('Readback qualification fails')
        result['reasons']=reasons
        result['status']='CONTEXT_ACTORS_NATIVE_FIXTURE_PASS' if not reasons else 'CONTEXT_ACTORS_NATIVE_FIXTURE_NOT_ACCEPTED'
    except (ValueError,OSError,subprocess.TimeoutExpired) as error:
        result['error']=str(error)
    finally:
        server.shutdown();server.server_close();thread.join(timeout=5)
        save_review(run,generator,bundle,result)
        print(result['status']);print('Evidence:',run)
    return 0 if result['status']=='CONTEXT_ACTORS_NATIVE_FIXTURE_PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
