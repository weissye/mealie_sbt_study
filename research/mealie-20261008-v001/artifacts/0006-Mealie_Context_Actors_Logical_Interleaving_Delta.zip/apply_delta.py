"""Apply only to the matching central generator baseline; preserve original files."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--generator-root',type=Path,required=True)
args=parser.parse_args();root=args.generator_root.resolve();bundle=Path(__file__).resolve().parent
hashes=json.loads((bundle/'baseline-hashes.json').read_text())
for name,expected in hashes.items():
    target=root/name
    if expected is None:
        if target.exists():raise SystemExit('Refusing to replace an existing actor module: '+str(target))
    elif not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=expected:
        raise SystemExit('Baseline differs; current source preserved. Compare before applying: '+str(target))
backup=root/'backups'/('before-context-actors-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
for name,expected in hashes.items():
    if expected is not None:
        destination=backup/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,destination)
try:
    for name in hashes:
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(bundle/'delta'/name,target)
    shutil.copytree(bundle/'delta/validation/context-actors',root/'validation/context-actors',dirs_exist_ok=True)
except Exception:
    for name,expected in hashes.items():
        if expected is None:(root/name).unlink(missing_ok=True)
        else:shutil.copy2(backup/name,root/name)
    raise
print('CONTEXT_ACTOR_DELTA_APPLIED')
print('Backup:',backup)
