param(
    [string]$GeneratorRoot = 'D:\Yeshayahu\Temp\mealie-home-20261007-195506-490\generator-current',
    [string]$ProvengoJar = '',
    [int]$Seed = 20261007,
    [switch]$InstallDelta
)
$ErrorActionPreference = 'Stop'
$package = $PSScriptRoot
if (-not (Test-Path -LiteralPath (Join-Path $package 'run_native.py'))) {
    $package = Join-Path $PSScriptRoot 'delta\validation\context-actors'
}
if (-not (Test-Path -LiteralPath (Join-Path $package 'run_native.py'))) { throw 'Native runner missing from this package.' }
if ($InstallDelta) {
    $installer = Join-Path $PSScriptRoot 'apply_delta.py'
    if (-not (Test-Path -LiteralPath $installer)) { throw 'Run -InstallDelta from the extracted delta root.' }
    & py -3 -B $installer --generator-root $GeneratorRoot
    if ($LASTEXITCODE -ne 0) { throw 'Delta installation stopped; current source preserved by baseline checks.' }
}
$pointer = Join-Path $package 'last-review-path.txt'
if (Test-Path -LiteralPath $pointer) { Remove-Item -LiteralPath $pointer }
$arguments = @('-3','-B',(Join-Path $package 'run_native.py'),'--generator-root',$GeneratorRoot,'--seed',"$Seed")
if ($ProvengoJar) { $arguments += @('--provengo-jar',$ProvengoJar) }
& py @arguments
$nativeExit = $LASTEXITCODE
if (-not (Test-Path -LiteralPath $pointer)) { throw 'No review archive was produced; native acceptance is not established.' }
$review = [IO.File]::ReadAllText($pointer).Trim()
Write-Host "Review ZIP: $review"
if ($nativeExit -ne 0) { throw "Native acceptance stopped (exit $nativeExit). Preserve $review. No acceptance claimed." }
& py -3 -B (Join-Path $package 'verify_archive.py') $review
if ($LASTEXITCODE -ne 0) { throw "Archive acceptance verification stopped. Preserve $review." }
Write-Host 'CONTEXT_ACTORS_RUN_AND_SAVE_PASS'
