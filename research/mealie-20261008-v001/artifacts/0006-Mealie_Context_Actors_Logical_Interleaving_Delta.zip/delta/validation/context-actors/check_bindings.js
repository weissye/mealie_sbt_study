// Generated interface runtime-boundary checks. This is a Node harness, not Provengo.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const path=require('path');
const root=process.argv[2]||path.join(__dirname,'generated/spec/js');
const values={},events=[];
const box={JSON,Array,Object,String,Error,encodeURIComponent,
  bp:{Event:(name,data)=>({name,data}),EventSet:(name,test)=>({name,test}),log:{info:()=>{}}},
  RESTSession:function(base,name,options){this.baseURL=base;this.defaultHeaders=options.headers;},
  pvg:{rtv:{get:k=>values[k],set:(k,v)=>{values[k]=v;}},fail:s=>{throw Error(s);}},
  cloneExpected:v=>JSON.parse(JSON.stringify(v)),
  sync:options=>{if(options.request)events.push(options.request);return options.request;},
  request:e=>{events.push(e);return e;}};
vm.createContext(box);vm.runInContext(fs.readFileSync(path.join(root,'interfaces.fixture.js'),'utf8'),box);
box.createFixtureResource('FixtureResource_1',{name:'owned-A'},{});
box.createFixtureResource('FixtureResource_2',{name:'owned-B'},{});
let http=events.filter(e=>e.data&&e.data.lib==='REST');
assert.deepEqual(http.map(e=>e.data.model.actor),['A','B']);
assert.equal(http[0].data.headers.Authorization,"Bearer @{java.lang.System.getenv('SBT_ACTOR_A_TOKEN')}");
assert.equal(http[1].data.headers.Authorization,"Bearer @{java.lang.System.getenv('SBT_ACTOR_B_TOKEN')}");
assert.throws(()=>box.createFixtureResource('unbound',{name:'bad'},{}),/Missing explicit actor/);
events.length=0;
const resource={id:'FixtureResource_1',expected:{name:'owned-A'},revision:2,verifiedRevision:2};
box.observeProcess0(resource,'ID_FixtureResource_1','ROUTE_FixtureResource_1','test_A','A','A');
box.observeProcess0(resource,'ID_FixtureResource_1','ROUTE_FixtureResource_1','test_B','B','A');
http=events.filter(e=>e.data&&e.data.lib==='REST');
assert.deepEqual(http.map(e=>e.data.model.actor),['A','B']);
assert.equal(http[0].data.url,http[1].data.url);
assert.notEqual(http[0].data.headers.Authorization,http[1].data.headers.Authorization);
http[1].data.callback({code:200,body:'{}'});
assert.equal(JSON.parse(values.OBS_test_B).actor,'B');
values.ID_FixtureResource_1='fixture-1';
box.readObservedTarget({id:'test_B',targets:[{}]},
 {logicalId:'FixtureResource_1',actor:'A',identityField:'id',identityKey:'ID_FixtureResource_1',
  expected:{name:'owned-A'},url:'/resources/fixture-1',codes:[200]},0);
http=events.filter(e=>e.data&&e.data.lib==='REST');
assert.equal(http.at(-1).data.model.actor,'A');
http.at(-1).data.callback({code:200,body:JSON.stringify({id:'fixture-1',name:'owned-A'})});
const observation=JSON.parse(values.OBS_test_B);
assert.equal(observation.observationsComplete,true);
assert.equal(observation.readbacks[0].identityMatches,true);
const story=fs.readFileSync(path.join(root,'stories.fixture.js'),'utf8');
for(const id of ['process_0_FixtureResource_1_A','process_0_FixtureResource_1_B',
                 'process_0_FixtureResource_2_A','process_0_FixtureResource_2_B'])assert(story.includes(id));
// Exercise the actual generated DAL effects through create, update and verification.
const entities=new Map(),effects={},queries={};
box.ctx={Entity:(id,type,props)=>({id,type,...props}),
  insertEntity:e=>entities.set(e.id,e),removeEntity:id=>entities.delete(id),
  registerEffect:(name,fn)=>effects[name]=fn,registerQuery:(name,fn)=>queries[name]=fn,
  runQuery:name=>Array.from(entities.values()).filter(queries[name])};
box.extractEventData=event=>event.data.model;
vm.runInContext(fs.readFileSync(path.join(root,'dal.js'),'utf8'),box);
effects.POST({model:{action:'create',logicalId:'test_resource',type:'FixtureResource',actor:'A',expected:{name:'first'}}});
assert.equal(entities.get('test_resource').actorId,'A');
effects.ModelVerified({logicalId:'test_resource',revision:1});
assert.equal(entities.get('test_resource').actorId,'A');
effects.PATCH({model:{action:'update',logicalId:'test_resource',actor:'B',expected:{name:'second'}}});
assert.equal(entities.get('test_resource').actorId,'A');
effects.ModelVerified({logicalId:'test_resource',revision:2});
assert.equal(entities.get('test_resource').actorId,'A');
assert.equal(entities.get('test_resource').verifiedRevision,2);
console.log('ACTOR_BINDING_NODE_CHECK_PASS: independent headers, shared resource, separate resources, actor/readback attribution, missing-binding rejection.');
