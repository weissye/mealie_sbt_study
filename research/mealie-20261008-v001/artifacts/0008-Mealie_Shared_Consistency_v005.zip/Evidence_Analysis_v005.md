# Preserved F04/F05 evidence analysis

Reviewed sources: qualification.json from multi-identity-20261005-065704 and scope-controls-20261005-073218, preserved under mealie-f04-existing-evidence-20261007-094139.

F04: multi-identity records four server-error manifestations in two separate-context runs, while its two shared-context runs list no independent issues. Scope-controls records eight HTTP 500 responses in two reference-control runs. Together these account for twelve reference-related 500 observations in six runs; the overall two bundles include eight runs. These are manifestations, not twelve independent bugs. Their source commits differ, so they are not one uniform reset campaign.

F05: scope-controls records four changes across two household-control runs: item count rises from two to three, visible through owner observations after the failing operation. The file labels them unauthorized_changes. That label is not an independently established authorization conclusion. Effective write policy, transaction boundaries and server root cause require separate qualification. Scope-controls records four additional 500 responses in these household-control runs; these should not be added to the twelve reference-control observations as independent defects.

Limitations: multi-identity explicitly marks unauthorized_mutation_demonstrated, root_cause_verified and reset_replay_verified false. Scope-controls marks reset_replay_completed and minimal_reproduction_completed false. Preserved evidence supports server-error and partial-state-change candidates; it does not establish a new replay, a confirmed authorization bypass or an atomicity guarantee from the contract.

The new shared consistency control checks authorized cross-user readback of a normal successful update. Passing it establishes only that baseline. Failing it requires inspection of permission configuration, server version and request outcomes before classifying a defect.
