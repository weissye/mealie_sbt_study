"""Two-user consistency control for dedicated shared Mealie shopping lists."""
import argparse, datetime, getpass, json, os, pathlib, urllib.request, urllib.error, urllib.parse, uuid, zipfile, secrets

VERSION = 'v005'

def main():
 print('MEALIE_SHARED_CONSISTENCY '+VERSION,flush=True)
 p=argparse.ArgumentParser(); p.add_argument('--base-url',default='http://127.0.0.1:9925'); p.add_argument('--admin-email',default='changeme@example.com'); a=p.parse_args()
 base=a.base_url.rstrip('/')
 if not base.startswith(('http://','https://')): p.error('HTTP(S) base URL required')
 tokens={}
 run=pathlib.Path(__file__).resolve().parent/'runs'/(VERSION+'-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'));run.mkdir(parents=True)
 events=[]; result={'version':VERSION,'script':pathlib.Path(__file__).name,'status':'NOT_ACCEPTED','created_resources':[], 'created_users':[], 'checks':[], 'execution':'sequential HTTP, logical actor switching'}
 def req(actor,method,path,body=None):
  raw=None if body is None else json.dumps(body).encode()
  r=urllib.request.Request(base+path,data=raw,method=method,headers={'Authorization':'Bearer '+tokens[actor],'Content-Type':'application/json'})
  event={'actor':actor,'method':method,'path':path,'status':None,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  events.append(event)
  timeout=120 if path=='/api/admin/users' and method=='POST' else 30
  print(actor+' '+method+' '+path+' (timeout '+str(timeout)+'s)',flush=True)
  try:
   with urllib.request.urlopen(r,timeout=timeout) as h: code=h.status; data=json.loads(h.read())
  except urllib.error.HTTPError as e:
   code=e.code; data={'http_error':code}
  except Exception as e:
   event['error_type']=type(e).__name__;event['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
   raise RuntimeError(method+' '+path+' stopped: '+type(e).__name__) from None
  event['status']=code;event['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  if not 200<=code<300: raise RuntimeError('HTTP failure: '+str(code)+' '+method+' '+path)
  return data
 def check(ok,label):
  result['checks'].append({'label':label,'pass':bool(ok)})
  if not ok: raise RuntimeError(label)
 def login(email,password):
  data=urllib.parse.urlencode({'username':email,'password':password}).encode()
  request=urllib.request.Request(base+'/api/auth/token',data=data,headers={'Content-Type':'application/x-www-form-urlencoded'})
  try:
   with urllib.request.urlopen(request,timeout=30) as response:
    token=json.loads(response.read()).get('access_token')
  except urllib.error.HTTPError as e:
   raise RuntimeError('Login failed (HTTP '+str(e.code)+')') from None
  if not token: raise RuntimeError('Login returned no access token')
  return token
 try:
  tokens['ADMIN']=login(a.admin_email,getpass.getpass('Admin password: '))
  admin=req('ADMIN','GET','/api/users/self')
  check(admin.get('admin') is True,'admin identity confirmed')
  check(admin.get('group') and admin.get('household'),'admin group and household available')
  for actor in ('A','B'):
   username='sbt_shared_'+actor.lower()+'_'+uuid.uuid4().hex[:12]
   email=username+'@example.com';password=secrets.token_urlsafe(32)
   user_record={'username':username,'actor':actor,'status':'CREATE_PENDING'}
   result['created_users'].append(user_record)
   created=req('ADMIN','POST','/api/admin/users',{
    'username':username,'fullName':'SBT Shared Control '+actor,'email':email,
    'password':password,'admin':False,'group':admin['group'],
    'household':admin['household'],'canOrganize':True})
   user_record.update(id=created.get('id'),status='CREATED')
   tokens[actor]=login(email,password)
  tokens.pop('ADMIN')
  users={k:req(k,'GET','/api/users/self') for k in ('A','B')}
  check(users['A'].get('id') and users['B'].get('id') and users['A']['id']!=users['B']['id'],'distinct users')
  for field in ('groupId','householdId'):
   check(users['A'].get(field) and users['A'][field]==users['B'].get(field),'same '+field)
  for creator,writer in [('A','B'),('B','A')]:
   name='sbt-shared-control-'+uuid.uuid4().hex
   item=req(creator,'POST','/api/households/shopping/lists',{'name':name,'extras':{}})
   identity=item['id'];result['created_resources'].append({'id':identity,'creator':creator})
   path='/api/households/shopping/lists/'+identity
   initial={k:req(k,'GET',path) for k in tokens}
   check(all(x.get('name')==name and x.get('id')==identity for x in initial.values()),'shared initial read '+creator)
   current=initial[writer]
   check(current.get('groupId')==users[creator]['groupId'],'list group matches')
   check(current.get('listItems',[])==[],'dedicated list remains empty')
   body={k:current[k] for k in ('name','extras','createdAt','update_at','groupId','userId','id','listItems') if k in current}
   body['name']=name+'-updated-by-'+writer
   req(writer,'PUT',path,body)
   for reader in (creator,writer,creator):
    state=req(reader,'GET',path)
    check(state.get('name')==body['name'] and state.get('id')==identity and state.get('listItems',[])==[],'update readback '+creator+' '+reader)
  result['status']='SHARED_CONSISTENCY_PASS'
 except Exception as e: result['error']=str(e)
 finally:
  (run/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
  (run/'http-events.json').write_text(json.dumps(events,indent=2),encoding='utf-8')
  with zipfile.ZipFile(run/'review.zip','w',zipfile.ZIP_DEFLATED) as z:
   for n in ('result.json','http-events.json'): z.write(run/n,n)
  print(result['status']);print('Review ZIP:',run/'review.zip')
 return 0 if result['status']=='SHARED_CONSISTENCY_PASS' else 1
if __name__=='__main__': raise SystemExit(main())
