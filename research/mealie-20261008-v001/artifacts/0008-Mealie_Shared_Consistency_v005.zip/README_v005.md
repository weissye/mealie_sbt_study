# Mealie shared consistency control

Run Run-Shared-Consistency-v005.ps1; default server http://127.0.0.1:9925 and admin email changeme@example.com, as recorded in the preserved study. Override with -BaseUrl or -AdminEmail if needed. Only the admin password is prompted, using hidden input. Python 3 standard library only.

The runner signs in as admin, verifies admin status and creates two non-admin users in the admin group and household with canOrganize enabled. Random user passwords and access tokens stay in memory and are not saved. Both user identities and matching groupId/householdId are checked before creating shopping lists.

Each user creates a dedicated empty list. The other user changes its name and both users read it back. Identity, owner, group and list items are preserved. Sequential HTTP only; no Provengo or true concurrency. This is an authorized shared consistency control, not F04/F05 reproduction.

The two users and two lists remain for review/manual cleanup; recorded IDs and usernames are in result.json. No existing account is modified. Failure stops the run and review.zip preserves sanitized request metadata and the outcome. A timeout can leave a resource without a recorded ID; unique sbt_shared_ and sbt-shared-control prefixes help locate it.

Validation uses a local simulated API; live Mealie and Windows execution remain unverified until the user's review.zip is inspected.

User creation waits up to 120 seconds. Other requests wait 30 seconds. Requests are not automatically retried. Request starts, failures and candidate usernames are recorded to distinguish timeout from HTTP rejection. CREATE_PENDING means the server outcome is unknown.

Configuration version: v005. Package and script names are versioned. The launcher and runner print v005; result.json records version and runner filename. Use the exact v005 package filter and launcher command. Future changes must increment this version.
