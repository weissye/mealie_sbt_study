param([string]$BaseUrl = 'http://127.0.0.1:9925', [string]$AdminEmail = 'changeme@example.com')
$ErrorActionPreference = 'Stop'
$manifest = Get-Content (Join-Path $PSScriptRoot 'manifest_v005.json') -Raw | ConvertFrom-Json
if ($manifest.version -ne 'v005') { throw 'Package version mismatch.' }
foreach ($entry in $manifest.sha256.PSObject.Properties) {
    $filePath = Join-Path $PSScriptRoot $entry.Name
    if ((Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash -ne $entry.Value) {
        throw ('Package checksum mismatch: ' + $entry.Name)
    }
}
Write-Host 'MEALIE_SHARED_CONSISTENCY v005 launcher'
$runner = Join-Path $PSScriptRoot 'run_shared_v005.py'
if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 $runner --base-url $BaseUrl --admin-email $AdminEmail }
elseif (Get-Command python -ErrorAction SilentlyContinue) { & python $runner --base-url $BaseUrl --admin-email $AdminEmail }
else { throw 'Python 3 is required.' }
if ($LASTEXITCODE -ne 0) { throw 'Consistency check was not accepted. Preserve review.zip.' }
