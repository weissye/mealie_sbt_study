import importlib.util,json,sys,urllib.parse
from pathlib import Path
s=importlib.util.spec_from_file_location('runner',Path(__file__).with_name('run_shared_v005.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
accounts={'changeme@example.com':'ADMIN'};lists={}
class R:
 status=200
 def __init__(self,d):self.d=d
 def __enter__(self):return self
 def __exit__(self,*a):pass
 def read(self):return json.dumps(self.d).encode()
def call(req,timeout=30):
 path=urllib.parse.urlsplit(req.full_url).path
 if path=='/api/auth/token':return R({'access_token':accounts[urllib.parse.parse_qs(req.data.decode())['username'][0]]})
 actor=req.headers['Authorization'].split()[-1]
 if path=='/api/users/self':return R({'id':actor,'admin':actor=='ADMIN','group':'Home','household':'Family','groupId':'g','householdId':'h'})
 if path=='/api/admin/users':
  d=json.loads(req.data);actor='A' if len(accounts)==1 else 'B';accounts[d['email']]=actor;return R({'id':actor})
 if req.method=='POST':
  d=json.loads(req.data);d.update(id=str(len(lists)+1),groupId='g',userId=actor,listItems=[]);lists[d['id']]=d;return R(d)
 identity=path.rsplit('/',1)[-1]
 if req.method=='PUT':lists[identity]=json.loads(req.data)
 return R(lists[identity])
m.urllib.request.urlopen=call;m.getpass.getpass=lambda _: 'local-test-password';sys.argv=['runner']
assert m.main()==0
assert len(lists)==2 and len(accounts)==3
print('LOCAL_ADMIN_FLOW_PASS')
