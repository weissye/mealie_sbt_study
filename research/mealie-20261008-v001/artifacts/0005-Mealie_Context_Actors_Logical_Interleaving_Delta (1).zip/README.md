# Context actors: logical interleaving

This delta extends the existing generator_v56 context-generate path. It does not introduce another compiler. Generated interfaces, DAL and stories include actor bindings. HTTP requests remain sequential. No concurrency coordinator is included.

Actor configuration references distinct token environment variables; token values do not appear in generated source. Existing accounts supply tokens at execution. This increment does not provision accounts, log users in, infer permissions, or generate authorization-boundary probes.

The fixture deliberately grants both actors access to both resources. Its purpose is to verify identity dispatch and logical scheduling independently of application authorization semantics.

## Apply

Extract this ZIP into a separate directory. Use the current directory containing generator_v56 as the generator root:

```powershell
py -3 .\apply_delta.py --generator-root 'YOUR_DIRECTORY_CONTAINING_generator_v56'
```

The installer checks hashes against the source snapshot in review(20261007-103347).zip. It refuses to overwrite a different baseline. Original files are backed up. Changes: generator_v56/cli.py, render/context_model.py, render/context_processes.py, and the new render/context_actors.py.

## Native acceptance

From the generator root, with the existing Provengo CLI on PATH:

```powershell
py -3 .\validation\context-actors\run_native.py --generator-root .
```

Expected acceptance marker: CONTEXT_ACTORS_NATIVE_FIXTURE_PASS. This launches one single-threaded local fixture with dummy tokens, generates JS through the central CLI, and runs native Provengo. It verifies one lifecycle per actor, both actors observing both resources, actor attribution, identity-matched readbacks and 18 successful fixture requests. It retains the actual execution order, generated model, native log and result under runs/context-actors-<timestamp>. Repeat with --seed only when actual schedule diversity is being measured; different seeds alone do not establish different orders.

## Generated configuration

fixtures/actors.json assigns FixtureResource_1 to A and FixtureResource_2 to B. Both A and B receive independent processes for each resource. An optional readback_actor selects a distinct reader for observations. Each action/readback carries an explicit actor; no global token switching occurs.

Actor.All in DAL records declared actors. Resource records retain actorId across updates. Declaring an actor is not proof that its token is valid or that it has permission; real response checks remain required.

The base process renderer still supports only its documented simple action shape. Typed action bodies and additional route dependencies, automatic multi-user login, scope-policy inference, and multi-actor contribution/copy/removal experiment templates are not implemented in this delta. Do not label it a new F04/F05 live reproduction.

## Checks completed here

Generated JS syntax checks, Node interface/callback actor checks, missing/invalid binding rejection, and generation byte compatibility for F01, F02, no-merge control and F03 all passed. The old single-actor output is unchanged when --actor-config is omitted.

Native acceptance now passed using the uploaded Provengo 0.7.5-SNAPSHOT JAR. check_bindings.js remains a separate Node harness. The actual native evidence is retained in native-acceptance/review.zip.

## JAR execution and verification fix

An existing JAR can be used directly:

```powershell
py -3 .\validation\context-actors\run_native.py --generator-root . --provengo-jar 'C:\path\to\provengo.jar'
```

The updated DAL preserves actorId when ModelVerified replaces the resource entity. The Node check exercises create, verification, update by another actor, and verification again; the original lifecycle actor remains attached. Local checks and native fixture execution pass; this does not establish Mealie replay.

## Project-style PowerShell entry point

From the extracted delta directory:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
Unblock-File .\Run-Context-Actors.ps1
& .\Run-Context-Actors.ps1 -InstallDelta
```

The default GeneratorRoot is the last root recorded in the previous chat:
`D:\Yeshayahu\Temp\mealie-home-20261007-195506-490\generator-current`.
Use `-GeneratorRoot` if the working root has since changed. Installation remains guarded by exact baseline hashes; a different source tree is preserved and the script stops.
For an already installed delta, omit `-InstallDelta`. Use `-ProvengoJar 'C:\path\Provengo.uber.jar'` to select an existing JAR instead of CLI on PATH.

The wrapper calls `py -3 -B`, checks the native exit code, prints `review.zip`, and verifies successful archives. The archive retains generator source, actor configuration, native output, generated model and fixture receipts when execution occurred. Missing Provengo produces `BLOCKED_PROVENGO_UNAVAILABLE`, a retained review archive and a failing exit code. Git commits and pushes are not performed.

The initial authoring attempt was blocked because no runtime was present. After receiving the uploaded JAR, native execution passed. The historical blocked attempt is retained in authoring-native-attempt.json. Node actor checks passed. PowerShell itself is not installed in this authoring environment, so the PowerShell wrapper has not been executed here. This is a generic local fixture runner, not a Mealie F04/F05 replay script.

## Native acceptance completed

Provengo 0.7.5-SNAPSHOT was executed with the uploaded JAR and returned exit 0. Both actors created one resource; both actors then executed the configured harmless action on both explicitly shared resources. All 18 fixture requests succeeded. Four observations had identity-matched, expected-state-matched readbacks. `CONTEXT_ACTORS_NATIVE_FIXTURE_PASS` and `CONTEXT_ACTORS_ARCHIVE_VERIFIED` were both produced. `native-acceptance/review.zip` preserves the accepted native run, source and logs. This does not establish schedule diversity or any F04/F05 Mealie reproduction.

The first native run passed, but its review archive did not pass integrity verification. The archive writer was changed to validate a temporary ZIP before replacing review.zip. A subsequent native run and archive verification both passed; the embedded evidence is from that accepted subsequent run.
