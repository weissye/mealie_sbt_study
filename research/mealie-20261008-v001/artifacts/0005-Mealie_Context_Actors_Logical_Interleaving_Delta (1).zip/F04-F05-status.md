# F04/F05 completion status — 2026-10-08

| Item | Established result |
| --- | --- |
| F01–F03 | Prior live confirmations retained; no new confirmation campaign performed. |
| F04 | Frozen old campaigns retain twelve unavailable-reference server-error observations across eight runs. No new central-process live confirmation. |
| F05 | Four frozen observations retain an owner-visible intermediate state change after failure. Effective authorization policy remains a separate unresolved qualification. No new central-process live confirmation. |
| Generic actor support | Existing central generator emits two actor sessions and four actor/resource process combinations; logical interleaving and sequential HTTP only. |
| Local acceptance | Generated JavaScript syntax, actor dispatch, readback attribution and DAL actor preservation checks pass. |
| Native acceptance | PASS using uploaded Provengo 0.7.5-SNAPSHOT JAR: native exit 0, eighteen successful fixture requests, all four actor/resource combinations, four qualified readbacks, accepted archive verified. |
| New Mealie execution | Not performed here. |

This package completes the generic actor delta only. It does not contain active F04/F05 vulnerability-reproduction templates and must not be reported as completed F04/F05 replay. Historical evidence and fixture acceptance are different results.
