[CmdletBinding()]
param([string[]]$SearchRoots, [string]$ResumeStaging)
$ErrorActionPreference = 'Stop'
$version = 'v002'
Write-Host "MEALIE_RESEARCH_COLLECTOR $version"
Add-Type -AssemblyName System.IO.Compression.FileSystem
$downloads = Join-Path $env:USERPROFILE 'Downloads'
if (-not (Test-Path -LiteralPath $downloads)) { throw 'Downloads directory does not exist.' }
if ($ResumeStaging) {
 $resume = (Get-Item -LiteralPath $ResumeStaging -ErrorAction Stop).FullName
 if (-not (Test-Path (Join-Path $resume 'files')) -and -not (Test-Path (Join-Path $resume 'trees'))) { throw 'No collected files found in staging. Run a new scan without -ResumeStaging.' }
 $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
 $outZip = Join-Path $downloads "Mealie_Research_Collection_v002-recovered-$stamp.zip"
 $inventory = @(Get-ChildItem -LiteralPath $resume -Recurse -File | ForEach-Object {
  [pscustomobject]@{archive_path=$_.FullName.Substring($resume.Length+1);sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash;source='Original source path unavailable after interrupted v001'}
 })
 ConvertTo-Json -InputObject $inventory -Depth 6 | Set-Content (Join-Path $resume 'manifest_v002.json') -Encoding UTF8
 $summary = [ordered]@{version='v002';mode='RECOVER_INTERRUPTED_V001';staging=$resume;recovered_file_count=$inventory.Count;completeness='UNVERIFIED';notes=@('Only files already copied by v001 are recovered.','Original source paths and missing-item list cannot be reconstructed from the interrupted process.','Inspect archive contents for missing targets; use a fresh scan if necessary.')}
 ConvertTo-Json -InputObject $summary -Depth 6 | Set-Content (Join-Path $resume 'summary_v002.json') -Encoding UTF8
 Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $resume 'Collect-Mealie-Research-v002.ps1') -Force
 [IO.Compression.ZipFile]::CreateFromDirectory($resume,$outZip,[IO.Compression.CompressionLevel]::Optimal,$false)
 $check=[IO.Compression.ZipFile]::OpenRead($outZip)
 try { if (-not ($check.Entries.FullName -contains 'summary_v002.json')) { throw 'ZIP verification failed.' } } finally { $check.Dispose() }
 Write-Host "COLLECTION_V002_RECOVERED: $($inventory.Count) files"
 Write-Host "ZIP: $outZip"
 Write-Host 'Recovered archive completeness is unverified; no rescan was performed.'
 return
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$stage = Join-Path $downloads "Mealie_Research_Collection_$version-$stamp"
New-Item -ItemType Directory -Path $stage | Out-Null
$targets = @(
 'Mealie_Shared_Consistency_v005*.zip',
 'review(20261008-121634).zip',
 'Mealie_Quantity_Consistency_Engineering_and_Research*.docx',
 'mealie-openapi.v3.28.0.reviewed.json'
)
$evidenceNames = @('multi-identity-20261005-065704','scope-controls-20261005-073218')
$found = New-Object 'System.Collections.Generic.List[object]'
$archives = New-Object 'System.Collections.Generic.List[string]'
$evidenceDirs = New-Object 'System.Collections.Generic.List[string]'
$sourceDirs = New-Object 'System.Collections.Generic.List[string]'
$issues = New-Object 'System.Collections.Generic.List[object]'
$seen = @{}
$skip = @('Windows','Program Files','Program Files (x86)','$Recycle.Bin','System Volume Information','.git','node_modules','.venv','venv','__pycache__')
if (-not $SearchRoots) {
 $SearchRoots = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { $_.DeviceID + '\' })
}
$stack = New-Object 'System.Collections.Generic.Stack[string]'
foreach ($root in $SearchRoots) {
 if (Test-Path -LiteralPath $root -PathType Container) { $stack.Push((Get-Item -LiteralPath $root).FullName) }
 else { $issues.Add([pscustomobject]@{path=$root;issue='Search root unavailable'}) }
}
$count = 0
while ($stack.Count -gt 0) {
 $dir = $stack.Pop()
 if ($seen.ContainsKey($dir)) { continue }; $seen[$dir]=$true
 if ($dir.StartsWith($stage,[StringComparison]::OrdinalIgnoreCase)) { continue }
 $count++
 if ($count % 250 -eq 0) { Write-Progress -Activity 'Searching local disks' -Status "$count directories scanned: $dir" }
 try { $entries = @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction Stop) }
 catch { $issues.Add([pscustomobject]@{path=$dir;issue='Directory unavailable'});continue }
 if ((Test-Path (Join-Path $dir 'pyproject.toml')) -and (Test-Path (Join-Path $dir 'mealie'))) { $sourceDirs.Add($dir) }
 foreach ($entry in $entries) {
  if ($entry.PSIsContainer) {
   if ($evidenceNames -contains $entry.Name) { $evidenceDirs.Add($entry.FullName) }
   if (($entry.Name -eq 'mealie') -and ((Test-Path (Join-Path $entry.FullName 'pyproject.toml')) -or (Test-Path (Join-Path $entry.FullName 'main.py')))) { $sourceDirs.Add($entry.FullName) }
   if ($skip -contains $entry.Name) { continue }
   if ($entry.Name -like 'Mealie_Research_Collection_v002-*') { continue }
   if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
   $stack.Push($entry.FullName)
  } else {
   foreach ($pattern in $targets) {
    if ($entry.Name -like $pattern) { $found.Add([pscustomobject]@{kind='named-file';path=$entry.FullName;target=$pattern}); break }
   }
   if ($entry.Extension -eq '.zip' -and $entry.Length -lt 2GB -and $entry.Name -notlike 'Mealie_Research_Collection_*') { $archives.Add($entry.FullName) }
  }
 }
}
Write-Progress -Activity 'Searching local disks' -Completed
Write-Host "Scanned $count directories. Inspecting ZIP inventories..."
foreach ($path in $archives) {
 $z = $null
 try {
  $z = [IO.Compression.ZipFile]::OpenRead($path)
  $matches = @($z.Entries | Where-Object {
   $_.FullName -match 'multi-identity-20261005-065704|scope-controls-20261005-073218|mealie-openapi\.v3\.28\.0\.reviewed\.json$'
  })
  if ($matches.Count -gt 0) { $found.Add([pscustomobject]@{kind='evidence-archive';path=$path;target='Evidence/OpenAPI located inside archive'}) }
 } catch { $issues.Add([pscustomobject]@{path=$path;issue='Could not inspect ZIP'}) }
 finally { if ($z) { $z.Dispose() } }
}
$index=0
$manifest=New-Object 'System.Collections.Generic.List[object]'
foreach ($item in @($found | Sort-Object path -Unique)) {
 $index++; $destDir=Join-Path $stage ('files\{0:D4}' -f $index);New-Item -ItemType Directory -Path $destDir -Force | Out-Null
 try {
  $dest=Join-Path $destDir (Split-Path $item.path -Leaf)
  Copy-Item -LiteralPath $item.path -Destination $dest
  $manifest.Add([pscustomobject]@{kind=$item.kind;source=$item.path;archive_path=$dest.Substring($stage.Length+1);sha256=(Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash})
 } catch { $issues.Add([pscustomobject]@{path=$item.path;issue='Copy failed'}) }
}
function Copy-ResearchTree([string]$root,[string]$kind) {
 $script:index++;$prefix=Join-Path $stage ('trees\{0:D4}' -f $script:index)
 $todo=New-Object 'System.Collections.Generic.Stack[string]';$todo.Push($root)
 while($todo.Count -gt 0) {
  $current=$todo.Pop()
  try { $entries=@(Get-ChildItem -LiteralPath $current -Force -ErrorAction Stop) }
  catch { $issues.Add([pscustomobject]@{path=$current;issue='Tree unavailable'});continue }
  foreach($f in $entries) {
   if($f.PSIsContainer) {
    if (($skip -notcontains $f.Name) -and -not ($f.Attributes -band [IO.FileAttributes]::ReparsePoint)) { $todo.Push($f.FullName) }
   } else {
    if($f.Name -like '.env*' -or $f.Extension -in @('.vhdx','.db','.sqlite','.sqlite3','.pem','.key')) { $issues.Add([pscustomobject]@{path=$f.FullName;issue='Credential/database file excluded'});continue }
    $relative=$f.FullName.Substring($root.TrimEnd('\').Length).TrimStart('\')
    $dest=Join-Path $prefix $relative
    try {
     New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null
     Copy-Item -LiteralPath $f.FullName -Destination $dest
     $manifest.Add([pscustomobject]@{kind=$kind;source=$f.FullName;archive_path=$dest.Substring($stage.Length+1);sha256=(Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash})
    } catch { $issues.Add([pscustomobject]@{path=$f.FullName;issue='Copy failed'}) }
   }
  }
 }
}
foreach($dir in @($evidenceDirs | Sort-Object -Unique)) { Copy-ResearchTree $dir 'evidence-tree' }
foreach($dir in @($sourceDirs | Sort-Object -Unique)) { Copy-ResearchTree $dir 'source-candidate-unverified-commit' }
$missing=New-Object 'System.Collections.Generic.List[string]'
foreach($pattern in $targets) { if(-not @($found | Where-Object {$_.target -eq $pattern}).Count) { $missing.Add($pattern+' (may exist inside a collected archive)') } }
foreach($name in $evidenceNames) { if(-not @($evidenceDirs | Where-Object {(Split-Path $_ -Leaf) -eq $name}).Count) { $missing.Add($name+' (may exist inside a collected archive)') } }
if($sourceDirs.Count -eq 0) { $missing.Add('Mealie source checkout: not located; commit correspondence remains unverified') }
$summary=[ordered]@{version=$version;search_roots=$SearchRoots;directories_scanned=$count;collected_files=$manifest.Count;missing_or_unresolved=$missing.ToArray();source_candidates=$sourceDirs.ToArray();notes=@('No source scripts were executed.','Source candidate commits are not verified.','Collected original ZIPs are copied unchanged and can contain credentials: review before sharing.','System directories, links, dependencies and git metadata were not traversed.','No original files were modified or deleted.')}
ConvertTo-Json -InputObject $manifest.ToArray() -Depth 6 | Set-Content (Join-Path $stage 'manifest_v002.json') -Encoding UTF8
ConvertTo-Json -InputObject $summary -Depth 6 | Set-Content (Join-Path $stage 'summary_v002.json') -Encoding UTF8
ConvertTo-Json -InputObject $issues.ToArray() -Depth 6 | Set-Content (Join-Path $stage 'issues_v002.json') -Encoding UTF8
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $stage 'Collect-Mealie-Research-v002.ps1')
$outZip=$stage+'.zip'
[IO.Compression.ZipFile]::CreateFromDirectory($stage,$outZip,[IO.Compression.CompressionLevel]::Optimal,$false)
$check=[IO.Compression.ZipFile]::OpenRead($outZip)
try { if(-not ($check.Entries.FullName -contains 'summary_v002.json')) {throw 'ZIP verification failed.'} } finally {$check.Dispose()}
Write-Host "COLLECTION_V001_COMPLETE: $($manifest.Count) files"
Write-Host "ZIP: $outZip"
Write-Host 'Unresolved items:'
$missing | ForEach-Object {Write-Host " - $_"}
Write-Host 'Review summary_v002.json and issues_v002.json before sharing.'
