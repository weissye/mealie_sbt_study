param([Parameter(Mandatory=$true)][string]$Repository)
$ErrorActionPreference = 'Stop'
$relative = 'evidence/native-context-closeout-20261006'
$source = Join-Path $PSScriptRoot $relative
$manifest = Get-Content -Raw -LiteralPath (Join-Path $source 'checksums.json') | ConvertFrom-Json
foreach ($record in $manifest.PSObject.Properties) {
    $file = Join-Path $source $record.Name
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.Value) {
        throw "Evidence checksum mismatch: $($record.Name)"
    }
}
$Repository = (Resolve-Path -LiteralPath $Repository).Path
& git -C $Repository fetch origin
if ($LASTEXITCODE -ne 0) { throw 'Fetch failed. Evidence remains in the extracted package.' }
& git -C $Repository merge-base --is-ancestor '21f753a8f2003d6f0d8a96217b39d063fcab1aff' origin/main
if ($LASTEXITCODE -ne 0) { throw 'Origin/main does not contain the verified first evidence commit.' }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$worktree = Join-Path (Split-Path -Parent $Repository) "mealie-f01-evidence-$stamp"
$branch = "archive-f01-$stamp"
& git -C $Repository worktree add -b $branch $worktree origin/main
if ($LASTEXITCODE -ne 0) { throw 'Worktree creation failed.' }
$target = Join-Path $worktree $relative
New-Item -ItemType Directory -Path $target -Force | Out-Null
foreach ($file in Get-ChildItem -LiteralPath $source -File -Recurse) {
    $name = $file.FullName.Substring($source.Length).TrimStart([char[]]'\/')
    $destination = Join-Path $target $name
    if (Test-Path -LiteralPath $destination) {
        if ((Get-FileHash -LiteralPath $destination).Hash -ne (Get-FileHash -LiteralPath $file.FullName).Hash) {
            throw "Existing evidence differs: $name. Worktree retained: $worktree"
        }
    } else {
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        Copy-Item -LiteralPath $file.FullName -Destination $destination
    }
}
& git -C $worktree add -f -- $relative
if ($LASTEXITCODE -ne 0) { throw "Staging failed. Worktree retained: $worktree" }
& git -C $worktree diff --cached --quiet -- $relative
$code = $LASTEXITCODE
if ($code -eq 1) {
    & git -C $worktree commit --only -m 'Freeze Mealie native Context closeout with both live runs and runnable source' -- $relative
    if ($LASTEXITCODE -ne 0) { throw "Commit failed. Worktree retained: $worktree" }
} elseif ($code -ne 0) { throw 'Staged change inspection failed.' }
foreach ($file in Get-ChildItem -LiteralPath $target -File -Recurse) {
    $name = $file.FullName.Substring($target.Length).TrimStart([char[]]'\/').Replace('\','/')
    $workingBlob = & git -C $worktree hash-object --no-filters -- $file.FullName
    if ($LASTEXITCODE -ne 0) { throw 'Working blob verification failed.' }
    $savedBlob = & git -C $worktree rev-parse "HEAD:$relative/$name"
    if ($LASTEXITCODE -ne 0 -or $savedBlob -ne $workingBlob) { throw "Committed evidence differs: $name" }
}
& git -C $worktree push origin HEAD:refs/heads/main
if ($LASTEXITCODE -ne 0) { throw "Push failed. Commit retained in $worktree. No force push was attempted." }
$local = & git -C $worktree rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'Local commit verification failed.' }
$remote = @(& git -C $worktree ls-remote --exit-code origin refs/heads/main)
if ($LASTEXITCODE -ne 0 -or $remote.Count -ne 1 -or ($remote[0] -split '\s+')[0] -ne $local) {
    throw 'Remote HEAD verification failed. Local evidence commit is retained.'
}
Write-Host "MEALIE_CLOSEOUT_PUSH_VERIFIED: $local"
Write-Host "Archive worktree: $worktree"
Write-Host 'Your original checkout and Docker state were not changed.'
