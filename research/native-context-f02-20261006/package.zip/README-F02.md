# F02 native Context merge/removal campaign

This is an isolated extension of the tested Context generator. Existing F01 artifacts and evidence are not overwritten. Each run generates JS from the pinned OpenAPI using context-removal, prints separate stories/interfaces/DAL paths, then invokes native Provengo. It is not a Python business workflow executor.

Food variant: two distinct foods, one unit, one recipe with quantities 2 and 2, one list and manual baseline 7. Add one recipe, merge source food into target food, then remove one recipe. Unit variant: two distinct units, one food and quantities 3 and 3. Positive arithmetic leaves baseline 7. We do not hardcode the erroneous Mealie outcome. Model state supplies expected aggregates; observations do not update the quantity oracle.

Lifecycles are independent bthreads. Source construction waits for all required ready resources without ordering independent creation. Manual item construction and source graph construction are separate. Contribution, merge and removal have separate bthreads. A Context verifier performs list GET, recipe GET, two item GETs and final list GET after each transition. Expected quantities compare canonical aggregates so row consolidation is permitted. Manual creation has its own direct child readback. All HTTP including authentication is in shared interfaces.

Declared resource consumption: merge deletes one new fixture food/unit as part of its documented operation. There is no cleanup, automatic retry or database reset. Never run against unrelated production resources. Raw native logs remain local and may contain credentials; upload review.zip, which excludes raw logs.

Start with food using scripts/Run-Mealie-Context-F02.ps1 -Variant food -Username changeme@example.com. Preserve its review.zip before running unit. The new package has native fixture acceptance, not yet Mealie live acceptance. Candidate stage 3 means a removal discrepancy; a prefix candidate means addition or merge failed earlier and is not evidence of removal coverage.

The generator generality claim remains limited: OpenAPI maps operation shapes, schemas and dependencies; merge/removal algebra is an explicitly named test hypothesis. This extension is not proof that semantic laws were derived automatically from schema alone.
