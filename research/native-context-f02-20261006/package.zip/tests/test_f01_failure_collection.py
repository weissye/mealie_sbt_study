import json,subprocess,sys,tempfile,unittest
from pathlib import Path
root=Path(__file__).resolve().parents[1]
class FailureCollectionTests(unittest.TestCase):
 def test_utf16_pre_contribution_failure_is_reported_without_credentials(self):
  with tempfile.TemporaryDirectory() as tmp:
   project=Path(tmp);(project/'spec/js').mkdir(parents=True);(project/'config').mkdir()
   log='Authorization: SECRET\nFAIL: Value mismatch $.rating: expected 1 observed null.\nTest Result: FAIL\n'
   (project/'native-run.log').write_bytes(log.encode('utf-16'))
   subprocess.run([sys.executable,str(root/'tools/collect_f01_evidence.py'),'--project',tmp],check=True,capture_output=True)
   report=json.loads((project/'qualification.json').read_text())
   self.assertEqual(report['status'],'F01_INCOMPLETE')
   self.assertEqual(report['termination']['reason']['path'],'$.rating')
   self.assertEqual(report['termination']['native_result'],'FAIL')
   self.assertNotIn('SECRET',json.dumps(report))
if __name__=='__main__':unittest.main()
