import json,tempfile,unittest,sys
from pathlib import Path
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r))
from generator_v56.render.context_removal import generate_removal
class RemovalTests(unittest.TestCase):
 def test_variants_deterministic_and_native_structure(self):
  for variant in ('food','unit'):
   with tempfile.TemporaryDirectory() as tmp:
    outputs=[]
    for name in ('a','b'):
     out=Path(tmp)/name/'spec/js';generate_removal(r/'model/mealie-openapi.v3.28.0.json',out,'http://127.0.0.1:9925',variant,20261007);outputs.append(out)
    for filename in ('stories.mealie.js','interfaces.mealie.js','dal.js'):self.assertEqual((outputs[0]/filename).read_bytes(),(outputs[1]/filename).read_bytes())
    s=(outputs[0]/'stories.mealie.js').read_text();self.assertIn('F02 canonical dependency merge',s);self.assertIn('F02 remove source contribution',s);self.assertNotIn('requestRest(',s)
    p=json.loads((outputs[0]/'generation_report.json').read_text())['plan'];self.assertEqual(p['merge_method'],'PUT');self.assertEqual(p['manual_quantity'],7)
    self.assertIn('F02.Pending',s);self.assertIn("waitForResource",s)
if __name__=='__main__':unittest.main()
