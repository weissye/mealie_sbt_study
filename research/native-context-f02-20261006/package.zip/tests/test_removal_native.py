"""Native Provengo against a local deterministic fixture, never a Mealie server."""
import argparse,json,os,sys,subprocess,threading,uuid
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
p=argparse.ArgumentParser();p.add_argument('--jar',required=True);p.add_argument('--output',required=True);p.add_argument('--variant',choices=['food','unit'],required=True);p.add_argument('--fault',action='store_true');a=p.parse_args()
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r));from generator_v56.render.context_removal import generate_removal
state={};requests=[]
def identity():return str(uuid.uuid4())
def items(lst):return lst['listItems']
def add(lst,recipe,scale):
 for row in recipe['recipeIngredient']:
  food=row['food']['id'];unit=row['unit']['id'];found=[x for x in items(lst) if x['foodId']==food and x['unitId']==unit]
  if not found:
   item=dict(id=identity(),quantity=0,foodId=food,unitId=unit,shoppingListId=lst['id'],recipeReferences=[]);items(lst).append(item);state['/api/households/shopping/items/'+item['id']]=item
  else:item=found[0]
  item['quantity']+=row['quantity']*scale
class H(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def reply(self,code,body):
  data=json.dumps(body).encode();self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_GET(self):self.handle_request()
 def do_POST(self):self.handle_request()
 def do_PUT(self):self.handle_request()
 def do_PATCH(self):self.handle_request()
 def handle_request(self):
  raw=self.rfile.read(int(self.headers.get('Content-Length',0)));body=json.loads(raw) if raw and self.path!='/api/auth/token' else {};path=self.path;requests.append((self.command,path))
  if path=='/api/auth/token':return self.reply(200,{'access_token':'fixture','token_type':'bearer'})
  if path.endswith('/merge'):
   k='Food' if '/foods/' in path else 'Unit';field=k.lower();fr=body['from'+k];to=body['to'+k];parent=state['/api/'+('foods' if k=='Food' else 'units')+'/'+to]
   for name,obj in list(state.items()):
    if name.startswith('/api/recipes/'):
     for row in obj.get('recipeIngredient',[]):
      if row[field]['id']==fr:row[field]=dict(parent)
    if name.startswith('/api/households/shopping/lists/'):
     for row in items(obj):
      if row[field+'Id']==fr:row[field+'Id']=to
     merged={}
     for row in items(obj):
      key=(row['foodId'],row['unitId'])
      if key in merged:
       merged[key]['quantity']+=row['quantity'];state.pop('/api/households/shopping/items/'+row['id'],None)
      else:merged[key]=row
     obj['listItems']=list(merged.values())
   state.pop('/api/'+('foods' if k=='Food' else 'units')+'/'+fr,None);return self.reply(200,{'message':'merged'})
  if path.endswith('/delete'):
   parts=path.split('/');lst=state['/'.join(parts[:6])];recipe=next(x for k,x in state.items() if k.startswith('/api/recipes/') and x['id']==parts[-2]);add(lst,recipe,-body['recipeDecrementQuantity']);lst['recipeReferences']=[]
   if a.fault:lst['listItems'][0]['quantity']+=2
   return self.reply(200,lst)
  if path.endswith('/recipe') and self.command=='POST':
   lst=state[path[:-7]];recipe=next(x for k,x in state.items() if k.startswith('/api/recipes/') and x['id']==body[0]['recipeId']);add(lst,recipe,1);lst['recipeReferences']=[{'recipeId':recipe['id'],'recipeQuantity':1,'id':identity(),'shoppingListId':lst['id']}];return self.reply(200,lst)
  if self.command=='POST':
   obj=dict(body,id=identity(),userId='fixture',groupId='fixture',householdId='fixture')
   if path=='/api/recipes':obj['slug']=obj['name'].lower();state[path+'/'+obj['slug']]=obj;return self.reply(201,obj['slug'])
   if path.endswith('/lists'):obj.update(listItems=[],recipeReferences=[])
   state[path+'/'+obj['id']]=obj
   if path.endswith('/items'):
    lst=next(x for k,x in state.items() if k.startswith('/api/households/shopping/lists/') and x['id']==obj['shoppingListId']);items(lst).append(obj);return self.reply(201,{'createdItems':[obj],'updatedItems':[],'deletedItems':[]})
   return self.reply(201,obj)
  if path not in state:return self.reply(404,{'detail':'absent'})
  if self.command in ('PUT','PATCH'):state[path].update(body)
  return self.reply(200,state[path])
server=ThreadingHTTPServer(('127.0.0.1',0),H);threading.Thread(target=server.serve_forever,daemon=True).start();out=Path(a.output);generate_removal(r/'model/mealie-openapi.v3.28.0.json',out/'spec/js','http://127.0.0.1:'+str(server.server_port),a.variant,20261007)
try:result=subprocess.run(['java','-jar',a.jar,'run',str(out)],env=dict(os.environ,SBT_USERNAME='fixture',SBT_PASSWORD='fixture'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=100)
finally:server.shutdown()
(out/'native-fixture.log').write_text(result.stdout);assert result.returncode==(1 if a.fault else 0),result.stdout[-4500:]
assert len([x for x in requests if x[1].endswith('/merge')])==1
assert len([x for x in requests if x[1].endswith('/delete')])==1
assert result.stdout.count('F02_RECEIPT ')==18,result.stdout[-1500:]
report={'native_exit':result.returncode,'variant':a.variant,'injected_quantity_fault':a.fault,'http_requests':len(requests),'receipts':18,'native_provengo_executed':True,'mealie_executed':False};(out/'result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
