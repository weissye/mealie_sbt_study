param(
    [string]$Root = (Split-Path -Parent $PSScriptRoot),
    [string]$BaseUrl = 'http://127.0.0.1:9925',
    [string]$Username = 'changeme@example.com',
    [ValidateSet('food','unit')][string]$Variant = 'food',
    [int]$Seed = 0,
    [switch]$GenerateOnly
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path -LiteralPath $Root).Path
& py -3 -B (Join-Path $Root 'tests\test_context_model.py')
if ($LASTEXITCODE -ne 0) { throw 'Baseline generator regression failed.' }
& py -3 -B (Join-Path $Root 'tests\test_context_removal.py')
if ($LASTEXITCODE -ne 0) { throw 'F02 generation regression failed.' }
$contract = Join-Path $Root 'model\mealie-openapi.v3.28.0.json'
if ((Get-FileHash -LiteralPath $contract).Hash.ToLowerInvariant() -ne '90e19aa713ab4ba15352627aca7dc37290f868b213eb65a3e1564f3b7a7ff292') { throw 'Pinned OpenAPI differs.' }
if ($Seed -eq 0) { $Seed = Get-Random -Minimum 1 -Maximum 1000000000 }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$project = Join-Path $Root "runs\native-f02-$Variant-$stamp-$Seed"
$output = Join-Path $project 'spec\js'
Push-Location $Root
try {
    & py -3 -B -m generator_v56 context-removal --openapi $contract --output $output --base-url $BaseUrl --variant $Variant --seed $Seed
    if ($LASTEXITCODE -ne 0) { throw 'Generation failed. Native execution was not started.' }
} finally { Pop-Location }
Write-Host "Stories: $(Join-Path $output 'stories.mealie.js')"
Write-Host "Interfaces: $(Join-Path $output 'interfaces.mealie.js')"
Write-Host "DAL: $(Join-Path $output 'dal.js')"
if ($GenerateOnly) { Write-Host 'F02_GENERATED_NOT_EXECUTED'; return }
Write-Host 'F02: fresh owned fixtures; manual baseline, recipe contribution, dependency merge and removal.'
Write-Host 'The declared merge consumes one newly created food or unit. No cleanup, retry or reset.'
$secure = Read-Host 'Mealie password (hidden)' -AsSecureString
$pointer = [IntPtr]::Zero
$previousUser = $env:SBT_USERNAME
$previousPassword = $env:SBT_PASSWORD
$previousPreference = $ErrorActionPreference
try {
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    $env:SBT_USERNAME = $Username
    $env:SBT_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    $ErrorActionPreference = 'Continue'
    & provengo run $project 2>&1 | Tee-Object -FilePath (Join-Path $project 'native-run.log')
    $nativeExit = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $previousPreference
    $env:SBT_USERNAME = $previousUser
    $env:SBT_PASSWORD = $previousPassword
    if ($pointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
    $secure = $null
}
& py -3 -B (Join-Path $Root 'tools\collect_f02_evidence.py') --project $project
if ($LASTEXITCODE -ne 0) { throw "Evidence collection failed. Retain $project" }
if ($nativeExit -ne 0) { throw 'F02 stopped. Preserve review.zip; no automatic retry was performed.' }
Write-Host 'F02_NATIVE_RUN_COMPLETED'
