import argparse,hashlib,json,zipfile,re
from pathlib import Path
from native_log_text import decode_native_log
p=argparse.ArgumentParser();p.add_argument('--project',required=True);a=p.parse_args();root=Path(a.project);raw=(root/'native-run.log').read_bytes();text=decode_native_log(raw);receipts=[];stages=[]
for line in text.splitlines():
 for marker,rows in [('F02_RECEIPT ',receipts),('F02_EVIDENCE ',stages)]:
  if marker in line:rows.append(json.loads(line.split(marker,1)[1]))
completed='Test Result: SUCCESS' in text and len(stages)==3 and all(not s['issues'] for s in stages)
last=stages[-1] if stages else None
status='F02_FUNCTIONAL_PASS' if completed else 'F02_REMOVAL_CANDIDATE' if last and last['stage']==3 and last['issues'] else 'F02_PREFIX_CANDIDATE' if last and last['issues'] else 'F02_INCOMPLETE'
report={'status':status,'completed':completed,'native_provengo_executed':True,'new_bug_confirmed':False,'receipts':receipts,'stages':stages,'native_log_sha256':hashlib.sha256(raw).hexdigest(),'raw_log_included':False,'limitation':'Candidate qualification requires independent evidence review; generation does not guarantee historical F02 reproduction.'}
(root/'qualification.json').write_text(json.dumps(report,indent=2))
with zipfile.ZipFile(root/'review.zip','w',zipfile.ZIP_DEFLATED) as z:
 for directory in ('spec/js','config'):
  for f in (root/directory).rglob('*'):
   if f.is_file() and f.suffix in ('.js','.json','.yml'):z.write(f,f.relative_to(root))
 z.write(root/'qualification.json','qualification.json')
print(status);print('Review ZIP: '+str(root/'review.zip'))
